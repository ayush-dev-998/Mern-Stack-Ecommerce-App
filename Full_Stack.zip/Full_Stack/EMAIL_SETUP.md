# Email Setup Instructions

To enable actual email sending, you need to:

1. Install nodemailer (already added to package.json):
   ```bash
   cd server
   npm install
   ```

2. Set up Gmail App Password:
   - Go to your Google Account settings
   - Enable 2-Step Verification
   - Generate an App Password for "Mail"
   - Copy the 16-character app password

3. Add environment variables to `server/.env`:
   ```
   EMAIL_USER=noreplyecommerce@gmail.com
   EMAIL_PASSWORD=your_16_character_app_password_here
   ```

4. The email service will automatically use these credentials to send emails from noreplyecommerce@gmail.com

Note: If EMAIL_PASSWORD is not set, the service will still work but emails won't be sent (it will log to console instead).

