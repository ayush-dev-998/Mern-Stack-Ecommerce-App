const FAQ = () => {
  const faqs = [
    {
      q: "How do I track my order?",
      a: "After your order ships, you will receive a tracking number via email."
    },
    {
      q: "Can I cancel my order?",
      a: "Orders can be cancelled or changed within 1 hour before they are processed."
    },
    {
      q: "Do you ship internationally?",
      a: "Yes, we ship to selected countries. Customs fees may apply."
    },
    {
      q: "What payment methods do you accept?",
      a: "We accept UPI, credit/debit cards, netbanking, and major wallets."
    },
    {
      q: "How do returns work?",
      a: "Returns can be initiated through your account or via customer support."
    }
  ];

  return (
    <section className="max-w-4xl mx-auto p-6 bg-white rounded-2xl shadow-sm">
      <h1 className="text-3xl font-semibold mb-4">FAQs</h1>
      <div className="space-y-4">
        {faqs.map((item, index) => (
          <details
            key={index}
            className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer"
          >
            <summary className="font-medium">{item.q}</summary>
            <p className="mt-2 text-gray-700">{item.a}</p>
          </details>
        ))}
      </div>
    </section>
  );
};

export default FAQ;
