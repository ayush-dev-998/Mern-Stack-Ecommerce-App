const ShippingPolicy = () => {
  return (
    <section className="max-w-4xl mx-auto p-6 bg-white rounded-2xl shadow-sm">
      <h1 className="text-3xl font-semibold mb-4">Shipping Policy</h1>
      <p className="text-sm text-gray-600 mb-6">
        Fast and reliable shipping for all orders placed on YourStore.
      </p>

      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-medium">Order Processing</h2>
          <p className="mt-2 text-gray-700">
            Orders are processed within 1–2 business days. Orders placed on
            weekends or holidays will be processed the next business day.
          </p>
        </div>

        <div>
          <h2 className="text-xl font-medium">Delivery Time</h2>
          <ul className="list-disc pl-6 mt-2 text-gray-700">
            <li>Standard Shipping: 3–7 business days</li>
            <li>Express Shipping: 1–3 business days</li>
            <li>International Shipping: Delivery time varies</li>
          </ul>
        </div>

        <div>
          <h2 className="text-xl font-medium">Shipping Charges</h2>
          <p className="mt-2 text-gray-700">
            Charges depend on weight, location, and shipping method. Free
            shipping on orders above <strong>$50</strong>.
          </p>
        </div>

        <div>
          <h2 className="text-xl font-medium">Tracking Information</h2>
          <p className="mt-2 text-gray-700">
            Once your order ships, we email you a tracking number.
          </p>
        </div>

        <div>
          <h2 className="text-xl font-medium">Damaged or Lost Items</h2>
          <p className="mt-2 text-gray-700">
            If your shipment arrives damaged, contact us within 7 days with
            photos. For lost items, we work with the courier to resolve the
            issue quickly.
          </p>
        </div>

        <div>
          <h2 className="text-xl font-medium">Returns</h2>
          <p className="mt-2 text-gray-700">
            Returns must be initiated within 7 days of delivery. Items should be
            unused and in original packaging.
          </p>
        </div>
      </div>
    </section>
  );
};

export default ShippingPolicy;
