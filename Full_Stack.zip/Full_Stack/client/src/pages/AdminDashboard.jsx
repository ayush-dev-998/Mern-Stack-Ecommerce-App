import { useState, useEffect } from 'react';
import {
  getStats,
  getUsers,
  deleteUser,
  approveSeller,
  rejectSeller,
  getCategories,
  createCategory,
  getAdminProducts,
  createAdminProduct,
  deleteAdminProduct,
  getAdminOrders,
} from '../api/admin';
import Pagination from '../components/Pagination';

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('users');
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [categoryName, setCategoryName] = useState('');
  const [productForm, setProductForm] = useState({
    title: '',
    description: '',
    price: '',
    images: '',
    inventoryCount: '',
    categoryId: '',
    sellerId: '',
  });

  useEffect(() => {
    fetchStats();
    fetchData();
  }, [activeTab, page]);

  const fetchStats = async () => {
    try {
      const response = await getStats();
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      switch (activeTab) {
        case 'users':
          const usersRes = await getUsers({ page, limit: 10 });
          console.log('Users response:', usersRes.data);
          setUsers(usersRes.data.users || []);
          setTotalPages(usersRes.data.pages || 1);
          break;
        case 'sellers':
          const sellersRes = await getUsers({ page, limit: 10, role: 'seller' });
          console.log('Sellers response:', sellersRes.data);
          setUsers(sellersRes.data.users || []);
          setTotalPages(sellersRes.data.pages || 1);
          break;
        case 'categories':
          const catsRes = await getCategories();
          setCategories(catsRes.data);
          break;
        case 'products':
          const prodsRes = await getAdminProducts({ page, limit: 10 });
          setProducts(prodsRes.data.products);
          setTotalPages(prodsRes.data.pages);
          break;
        case 'orders':
          const ordersRes = await getAdminOrders({ page, limit: 10 });
          setOrders(ordersRes.data.orders);
          setTotalPages(ordersRes.data.pages);
          break;
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };


  const handleDeleteUser = async (userId) => {
    if (!window.confirm('Are you sure you want to delete this user? They will need to register again.')) return;
    try {
      await deleteUser(userId);
      fetchData();
      fetchStats();
    } catch (error) {
      alert(error.response?.data?.message || 'Error deleting user');
    }
  };

  const handleCreateCategory = async (e) => {
    e.preventDefault();
    try {
      await createCategory({ name: categoryName });
      setCategoryName('');
      setShowCategoryForm(false);
      fetchData();
    } catch (error) {
      alert(error.response?.data?.message || 'Error creating category');
    }
  };

  const handleProductSubmit = async (e) => {
    e.preventDefault();
    
    // Validate price and inventory
    const priceNum = parseFloat(productForm.price);
    const inventoryNum = parseInt(productForm.inventoryCount);
    
    if (isNaN(priceNum) || priceNum < 0) {
      alert('Price must be a positive number');
      return;
    }
    
    if (isNaN(inventoryNum) || inventoryNum < 0) {
      alert('Inventory count must be a positive number');
      return;
    }
    
    try {
      const productData = {
        ...productForm,
        price: priceNum,
        inventoryCount: inventoryNum,
        images: productForm.images.split(',').map(url => url.trim()).filter(Boolean),
      };

      await createAdminProduct(productData);

      setShowProductForm(false);
      setEditingProduct(null);
      setProductForm({
        title: '',
        description: '',
        price: '',
        images: '',
        inventoryCount: '',
        categoryId: '',
        sellerId: '',
      });
      fetchData();
    } catch (error) {
      alert(error.response?.data?.message || 'Error saving product');
    }
  };

  const handleDeleteProduct = async (id) => {
    if (!window.confirm('Are you sure you want to delete this product?')) return;
    try {
      await deleteAdminProduct(id);
      fetchData();
    } catch (error) {
      alert(error.response?.data?.message || 'Error deleting product');
    }
  };

  const handleApproveSeller = async (userId) => {
    try {
      await approveSeller(userId);
      fetchData();
      fetchStats();
    } catch (error) {
      alert(error.response?.data?.message || 'Error approving seller');
    }
  };

  const handleRejectSeller = async (userId) => {
    if (!window.confirm('Are you sure you want to reject this seller? They will not be able to login again with this email.')) return;
    try {
      await rejectSeller(userId);
      fetchData();
      fetchStats();
    } catch (error) {
      alert(error.response?.data?.message || 'Error rejecting seller');
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>

      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-gray-600 text-sm">Total Users</p>
            <p className="text-2xl font-bold">{stats.totalUsers}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-gray-600 text-sm">Total Products</p>
            <p className="text-2xl font-bold">{stats.totalProducts}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-gray-600 text-sm">Total Orders</p>
            <p className="text-2xl font-bold">{stats.totalOrders}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-gray-600 text-sm">Buyers</p>
            <p className="text-2xl font-bold">{stats.totalBuyers}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-gray-600 text-sm">Sellers</p>
            <p className="text-2xl font-bold">{stats.totalSellers}</p>
          </div>
        </div>
      )}

      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-gray-600 text-sm">Total Returns/Replaces</p>
            <p className="text-2xl font-bold">{stats.totalReturns || 0}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-gray-600 text-sm">Pending Returns</p>
            <p className="text-2xl font-bold">{stats.pendingReturns || 0}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-gray-600 text-sm">Approved Returns</p>
            <p className="text-2xl font-bold">{stats.approvedReturns || 0}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-gray-600 text-sm">Completed Returns</p>
            <p className="text-2xl font-bold">{stats.completedReturns || 0}</p>
          </div>
        </div>
      )}

      <div className="flex space-x-4 mb-6">
        {['users', 'sellers', 'categories', 'products', 'orders'].map((tab) => (
          <button
            key={tab}
            onClick={() => {
              setActiveTab(tab);
              setPage(1);
            }}
            className={`px-4 py-2 rounded capitalize ${
              activeTab === tab ? 'bg-blue-600 text-white' : 'bg-gray-200'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'users' && (
        <>
          <h2 className="text-2xl font-bold mb-6">All Users</h2>
          {loading ? (
            <div className="text-center py-12">Loading...</div>
          ) : users.length === 0 ? (
            <div className="text-center py-12 text-gray-500">No users found</div>
          ) : (
            <>
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left">Name</th>
                      <th className="px-6 py-3 text-left">Email</th>
                      <th className="px-6 py-3 text-left">Role</th>
                      <th className="px-6 py-3 text-left">Status</th>
                      <th className="px-6 py-3 text-left">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user) => (
                      <tr key={user._id} className="border-t">
                        <td className="px-6 py-4">{user.name}</td>
                        <td className="px-6 py-4">{user.email}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded text-sm font-semibold ${
                            user.role === 'admin' ? 'bg-purple-100 text-purple-800' :
                            user.role === 'seller' ? 'bg-blue-100 text-blue-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          {user.role === 'seller' && (
                            <span className={`px-2 py-1 rounded text-xs ${
                              user.approvalStatus === 'approved' ? 'bg-green-100 text-green-800' :
                              user.approvalStatus === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {user.approvalStatus}
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-4">
                            <span className="text-sm text-gray-500">
                              {new Date(user.createdAt).toLocaleDateString()}
                            </span>
                            <button
                              onClick={() => handleDeleteUser(user._id)}
                              className="text-red-600 hover:text-red-800 text-sm"
                            >
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Pagination currentPage={page} totalPages={totalPages} onPageChange={setPage} />
            </>
          )}
        </>
      )}

      {activeTab === 'sellers' && (
        <>
          <h2 className="text-2xl font-bold mb-6">Seller Approvals</h2>
          {loading ? (
            <div className="text-center py-12">Loading...</div>
          ) : users.length === 0 ? (
            <div className="text-center py-12 text-gray-500">No sellers found</div>
          ) : (
            <>
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left">Name</th>
                      <th className="px-6 py-3 text-left">Email</th>
                      <th className="px-6 py-3 text-left">Store Name</th>
                      <th className="px-6 py-3 text-left">Status</th>
                      <th className="px-6 py-3 text-left">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user) => (
                      <tr key={user._id} className="border-t">
                        <td className="px-6 py-4">{user.name}</td>
                        <td className="px-6 py-4">{user.email}</td>
                        <td className="px-6 py-4">{user.sellerProfile?.storeName || 'N/A'}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded text-xs ${
                            user.approvalStatus === 'approved' ? 'bg-green-100 text-green-800' :
                            user.approvalStatus === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {user.approvalStatus}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-2">
                            {user.approvalStatus === 'pending' && (
                              <>
                                <button
                                  onClick={() => handleApproveSeller(user._id)}
                                  className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700"
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => handleRejectSeller(user._id)}
                                  className="bg-red-600 text-white px-3 py-1 rounded text-sm hover:bg-red-700"
                                >
                                  Reject
                                </button>
                              </>
                            )}
                            {user.approvalStatus === 'approved' && (
                              <button
                                onClick={() => handleRejectSeller(user._id)}
                                className="bg-red-600 text-white px-3 py-1 rounded text-sm hover:bg-red-700"
                              >
                                Reject
                              </button>
                            )}
                            <button
                              onClick={() => handleDeleteUser(user._id)}
                              className="bg-gray-600 text-white px-3 py-1 rounded text-sm hover:bg-gray-700"
                            >
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Pagination currentPage={page} totalPages={totalPages} onPageChange={setPage} />
            </>
          )}
        </>
      )}

      {activeTab === 'categories' && (
        <>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Categories</h2>
            <button
              onClick={() => setShowCategoryForm(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              Add Category
            </button>
          </div>

          {showCategoryForm && (
            <form onSubmit={handleCreateCategory} className="bg-white p-6 rounded-lg shadow-md mb-6">
              <div className="flex space-x-4">
                <input
                  type="text"
                  value={categoryName}
                  onChange={(e) => setCategoryName(e.target.value)}
                  placeholder="Category name"
                  required
                  className="flex-1 border rounded px-4 py-2"
                />
                <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded">
                  Create
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowCategoryForm(false);
                    setCategoryName('');
                  }}
                  className="bg-gray-200 px-6 py-2 rounded"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left">Name</th>
                  <th className="px-6 py-3 text-left">Slug</th>
                </tr>
              </thead>
              <tbody>
                {categories.map((cat) => (
                  <tr key={cat._id} className="border-t">
                    <td className="px-6 py-4">{cat.name}</td>
                    <td className="px-6 py-4">{cat.slug}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {activeTab === 'products' && (
        <>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Products</h2>
          </div>

          {showProductForm && (
            <div className="bg-white p-6 rounded-lg shadow-md mb-6">
              <h3 className="text-xl font-bold mb-4">Product Form</h3>
              <form onSubmit={handleProductSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block mb-2">Title *</label>
                    <input
                      type="text"
                      value={productForm.title}
                      onChange={(e) => setProductForm({ ...productForm, title: e.target.value })}
                      required
                      className="w-full border rounded px-4 py-2"
                    />
                  </div>
                  <div>
                    <label className="block mb-2">Price *</label>
                    <input
                      type="number"
                      value={productForm.price}
                      onChange={(e) => setProductForm({ ...productForm, price: e.target.value })}
                      required
                      min="0"
                      step="0.01"
                      className="w-full border rounded px-4 py-2"
                    />
                  </div>
                </div>
                <div>
                  <label className="block mb-2">Description *</label>
                  <textarea
                    value={productForm.description}
                    onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                    required
                    rows="4"
                    className="w-full border rounded px-4 py-2"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block mb-2">Category *</label>
                    <select
                      value={productForm.categoryId}
                      onChange={(e) => setProductForm({ ...productForm, categoryId: e.target.value })}
                      required
                      className="w-full border rounded px-4 py-2"
                    >
                      <option value="">Select Category</option>
                      {categories.map((cat) => (
                        <option key={cat._id} value={cat._id}>
                          {cat.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block mb-2">Seller ID *</label>
                    <input
                      type="text"
                      value={productForm.sellerId}
                      onChange={(e) => setProductForm({ ...productForm, sellerId: e.target.value })}
                      required
                      placeholder="Seller user ID"
                      className="w-full border rounded px-4 py-2"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block mb-2">Inventory Count *</label>
                    <input
                      type="number"
                      value={productForm.inventoryCount}
                      onChange={(e) => setProductForm({ ...productForm, inventoryCount: e.target.value })}
                      required
                      min="0"
                      className="w-full border rounded px-4 py-2"
                    />
                  </div>
                  <div>
                    <label className="block mb-2">Images (comma-separated)</label>
                    <input
                      type="text"
                      value={productForm.images}
                      onChange={(e) => setProductForm({ ...productForm, images: e.target.value })}
                      className="w-full border rounded px-4 py-2"
                    />
                  </div>
                </div>
                <div className="flex space-x-4">
                  <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded">
                    Create
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowProductForm(false)}
                    className="bg-gray-200 px-6 py-2 rounded"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          {loading ? (
            <div className="text-center py-12">Loading...</div>
          ) : (
            <>
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left">Product</th>
                      <th className="px-6 py-3 text-left">Price</th>
                      <th className="px-6 py-3 text-left">Seller</th>
                      <th className="px-6 py-3 text-left">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((product) => (
                      <tr key={product._id} className="border-t">
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-4">
                            <img
                              src={product.images?.[0] || 'https://via.placeholder.com/50'}
                              alt={product.title}
                              className="w-16 h-16 object-cover rounded"
                            />
                            <div>
                              <p className="font-semibold">{product.title}</p>
                              <p className="text-sm text-gray-500">{product.categoryId?.name}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">${product.price}</td>
                        <td className="px-6 py-4">{product.sellerId?.name}</td>
                        <td className="px-6 py-4">
                          <div className="flex space-x-2">
                            <button
                              onClick={() => handleDeleteProduct(product._id)}
                              className="text-red-600 hover:text-red-800"
                            >
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Pagination currentPage={page} totalPages={totalPages} onPageChange={setPage} />
            </>
          )}
        </>
      )}

      {activeTab === 'orders' && (
        <>
          <h2 className="text-2xl font-bold mb-6">Orders</h2>
          {loading ? (
            <div className="text-center py-12">Loading...</div>
          ) : (
            <>
              <div className="space-y-4">
                {orders.map((order) => (
                  <div key={order._id} className="bg-white rounded-lg shadow-md p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <p className="font-semibold text-lg">Order #{order._id.slice(-8)}</p>
                        <p className="text-sm text-gray-500">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </p>
                        <p className="text-sm">Buyer: {order.userId?.name}</p>
                        <p className="text-sm">Seller: {order.sellerId?.name}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-xl">${order.totalAmount.toFixed(2)}</p>
                        <span
                          className={`inline-block px-3 py-1 rounded text-sm ${
                            order.status === 'Delivered'
                              ? 'bg-green-100 text-green-800'
                              : order.status === 'Shipped'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-yellow-100 text-yellow-800'
                          }`}
                        >
                          {order.status}
                        </span>
                      </div>
                    </div>
                    <div className="border-t pt-4">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between mb-2">
                          <span>{item.productId?.title}</span>
                          <span>
                            {item.quantity} × ${item.unitPrice} = $
                            {(item.quantity * item.unitPrice).toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <Pagination currentPage={page} totalPages={totalPages} onPageChange={setPage} />
            </>
          )}
        </>
      )}
    </div>
  );
};

export default AdminDashboard;

