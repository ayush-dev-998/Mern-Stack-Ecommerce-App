import { useState, useEffect } from 'react';
import { getSellerProducts, createProduct, updateProduct, deleteProduct, getSellerOrders, updateOrderStatus, getSellerReturns, updateReturnStatus } from '../api/seller';
import { getCategories } from '../api/categories';
import Pagination from '../components/Pagination';
import { BASE_URL } from '../api/axios';
import { useAuth } from '../context/AuthContext';

const SellerDashboard = () => {
  const { user, fetchUser } = useAuth();
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [returns, setReturns] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [activeTab, setActiveTab] = useState('products');
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    inventoryCount: '',
    categoryId: '',
  });
  const [selectedImages, setSelectedImages] = useState([]);
  const [existingImages, setExistingImages] = useState([]);
  const [keepExistingImages, setKeepExistingImages] = useState(false);

  useEffect(() => {
    // Refresh user data to get latest approval status when component mounts
    fetchUser();
  }, []);

  useEffect(() => {
    fetchCategories();
    fetchProducts();
  }, [page]);

  useEffect(() => {
    if (activeTab === 'orders') {
      fetchOrders();
    } else if (activeTab === 'returns') {
      fetchReturns();
    }
  }, [activeTab, page]);

  const fetchCategories = async () => {
    try {
      const response = await getCategories();
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const response = await getSellerProducts({ page, limit: 10 });
      setProducts(response.data.products);
      setTotalPages(response.data.pages);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const response = await getSellerOrders({ page, limit: 10 });
      setOrders(response.data.orders);
      setTotalPages(response.data.pages);
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchReturns = async () => {
    setLoading(true);
    try {
      const response = await getSellerReturns();
      setReturns(response.data);
    } catch (error) {
      console.error('Error fetching returns:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);
    setSelectedImages(files);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Check approval status before submitting
    if (user?.approvalStatus !== 'approved') {
      alert('Your seller account is pending approval. You cannot add products until approved.');
      return;
    }
    
    // Validate price and inventory
    const priceNum = parseFloat(formData.price);
    const inventoryNum = parseInt(formData.inventoryCount);
    
    if (isNaN(priceNum) || priceNum < 0) {
      alert('Price must be a positive number');
      return;
    }
    
    if (isNaN(inventoryNum) || inventoryNum < 0) {
      alert('Inventory count must be a positive number');
      return;
    }
    
    try {
      const formDataToSend = new FormData();
      formDataToSend.append('title', formData.title);
      formDataToSend.append('description', formData.description);
      formDataToSend.append('price', priceNum);
      formDataToSend.append('inventoryCount', inventoryNum);
      formDataToSend.append('categoryId', formData.categoryId);
      
      if (editingProduct) {
        formDataToSend.append('keepExistingImages', keepExistingImages.toString());
      }

      // Append images (only if provided)
      if (selectedImages.length > 0) {
        selectedImages.forEach((image) => {
          formDataToSend.append('images', image);
        });
      }

      if (editingProduct) {
        await updateProduct(editingProduct._id, formDataToSend);
      } else {
        await createProduct(formDataToSend);
      }

      setShowProductForm(false);
      setEditingProduct(null);
      setFormData({
        title: '',
        description: '',
        price: '',
        inventoryCount: '',
        categoryId: '',
      });
      setSelectedImages([]);
      setExistingImages([]);
      setKeepExistingImages(false);
      fetchProducts();
    } catch (error) {
      alert(error.response?.data?.message || 'Error saving product');
    }
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setFormData({
      title: product.title,
      description: product.description,
      price: product.price,
      inventoryCount: product.inventoryCount,
      categoryId: product.categoryId._id || product.categoryId,
    });
    setExistingImages(product.images || []);
    setSelectedImages([]);
    setKeepExistingImages(true);
    setShowProductForm(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this product?')) return;

    try {
      await deleteProduct(id);
      fetchProducts();
    } catch (error) {
      alert(error.response?.data?.message || 'Error deleting product');
    }
  };

  const handleOrderStatusUpdate = async (orderId, newStatus) => {
    try {
      await updateOrderStatus(orderId, newStatus);
      fetchOrders();
    } catch (error) {
      alert(error.response?.data?.message || 'Error updating order status');
    }
  };

  // Debug: Log user approval status
  useEffect(() => {
    if (user) {
      console.log('Seller Dashboard - User approval status:', user.approvalStatus);
      console.log('Seller Dashboard - Full user object:', user);
    }
  }, [user]);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Seller Dashboard</h1>
      {user && (
        <div className="mb-4 text-sm text-gray-600">
          Approval Status: <span className="font-semibold">{user.approvalStatus || 'Not set'}</span>
        </div>
      )}

      <div className="flex space-x-4 mb-6">
        <button
          onClick={() => setActiveTab('products')}
          className={`px-4 py-2 rounded ${
            activeTab === 'products' ? 'bg-blue-600 text-white' : 'bg-gray-200'
          }`}
        >
          Products
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2 rounded ${
            activeTab === 'orders' ? 'bg-blue-600 text-white' : 'bg-gray-200'
          }`}
        >
          Orders
        </button>
        <button
          onClick={() => setActiveTab('returns')}
          className={`px-4 py-2 rounded ${
            activeTab === 'returns' ? 'bg-blue-600 text-white' : 'bg-gray-200'
          }`}
        >
          Returns
        </button>
      </div>

      {activeTab === 'products' && (
        <>
          {user?.approvalStatus === 'pending' && (
            <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-6">
              <p className="font-bold">Waiting for Admin Approval</p>
              <p>Your seller account is pending approval. You cannot add products until an admin approves your account.</p>
            </div>
          )}
          {user?.approvalStatus === 'rejected' && (
            <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
              <p className="font-bold">Account Rejected</p>
              <p>Your seller account has been rejected by an admin. Please contact support for more information.</p>
            </div>
          )}
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">My Products</h2>
            {user?.approvalStatus === 'approved' && (
              <button
                onClick={() => {
                  setShowProductForm(true);
                  setEditingProduct(null);
                  setFormData({
                    title: '',
                    description: '',
                    price: '',
                    inventoryCount: '',
                    categoryId: '',
                  });
                  setSelectedImages([]);
                  setExistingImages([]);
                  setKeepExistingImages(false);
                }}
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
              >
                Add Product
              </button>
            )}
          </div>

          {showProductForm && (
            <div className="bg-white p-6 rounded-lg shadow-md mb-6">
              <h3 className="text-xl font-bold mb-4">
                {editingProduct ? 'Edit Product' : 'Add New Product'}
              </h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block mb-2">Title *</label>
                  <input
                    type="text"
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                    required
                    className="w-full border rounded px-4 py-2"
                  />
                </div>
                <div>
                  <label className="block mb-2">Description *</label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    required
                    rows="4"
                    className="w-full border rounded px-4 py-2"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block mb-2">Price *</label>
                    <input
                      type="number"
                      name="price"
                      value={formData.price}
                      onChange={handleChange}
                      required
                      min="0"
                      step="0.01"
                      className="w-full border rounded px-4 py-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">Price cannot be negative</p>
                  </div>
                  <div>
                    <label className="block mb-2">Inventory Count *</label>
                    <input
                      type="number"
                      name="inventoryCount"
                      value={formData.inventoryCount}
                      onChange={handleChange}
                      required
                      min="0"
                      className="w-full border rounded px-4 py-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">Stock cannot be negative</p>
                  </div>
                </div>
                <div>
                  <label className="block mb-2">Category *</label>
                  <select
                    name="categoryId"
                    value={formData.categoryId}
                    onChange={handleChange}
                    required
                    className="w-full border rounded px-4 py-2"
                  >
                    <option value="">Select Category</option>
                    {categories.map((cat) => (
                      <option key={cat._id} value={cat._id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block mb-2">
                    Product Images {!editingProduct && '*'}
                  </label>
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageChange}
                    required={!editingProduct}
                    className="w-full border rounded px-4 py-2"
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    {editingProduct 
                      ? 'Optional: Select new images to add or replace existing ones (max 5)' 
                      : 'You can select multiple images (max 5)'}
                  </p>
                  {editingProduct && existingImages.length > 0 && (
                    <div className="mt-4">
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={keepExistingImages}
                          onChange={(e) => setKeepExistingImages(e.target.checked)}
                        />
                        <span>Keep existing images</span>
                      </label>
                      <div className="grid grid-cols-4 gap-2 mt-2">
                        {existingImages.map((img, idx) => (
                          <img
                            key={idx}
                            src={img?.startsWith('/uploads') ? `${BASE_URL}${img}` : img}
                            alt={`Existing ${idx + 1}`}
                            className="w-full h-24 object-cover rounded"
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                <div className="flex space-x-4">
                  <button
                    type="submit"
                    className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
                  >
                    {editingProduct ? 'Update' : 'Create'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowProductForm(false);
                      setEditingProduct(null);
                    }}
                    className="bg-gray-200 px-6 py-2 rounded hover:bg-gray-300"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          {loading ? (
            <div className="text-center py-12">Loading...</div>
          ) : products.length === 0 ? (
            <div className="text-center py-12 text-gray-500">No products found</div>
          ) : (
            <>
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left">Product</th>
                      <th className="px-6 py-3 text-left">Price</th>
                      <th className="px-6 py-3 text-left">Stock</th>
                      <th className="px-6 py-3 text-left">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((product) => (
                      <tr key={product._id} className="border-t">
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-4">
                            <img
                              src={product.images?.[0]?.startsWith('/uploads') ? `${BASE_URL}${product.images[0]}` : (product.images?.[0] || 'https://via.placeholder.com/50')}
                              alt={product.title}
                              className="w-16 h-16 object-cover rounded"
                            />
                            <div>
                              <p className="font-semibold">{product.title}</p>
                              <p className="text-sm text-gray-500">{product.categoryId?.name}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">${product.price}</td>
                        <td className="px-6 py-4">{product.inventoryCount}</td>
                        <td className="px-6 py-4">
                          <div className="flex space-x-2">
                            <button
                              onClick={() => handleEdit(product)}
                              className="text-blue-600 hover:text-blue-800"
                            >
                              Edit
                            </button>
                            <button
                              onClick={() => handleDelete(product._id)}
                              className="text-red-600 hover:text-red-800"
                            >
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Pagination currentPage={page} totalPages={totalPages} onPageChange={setPage} />
            </>
          )}
        </>
      )}

      {activeTab === 'orders' && (
        <>
          <h2 className="text-2xl font-bold mb-6">Orders</h2>
          {loading ? (
            <div className="text-center py-12">Loading...</div>
          ) : orders.length === 0 ? (
            <div className="text-center py-12 text-gray-500">No orders found</div>
          ) : (
            <>
              <div className="space-y-4">
                {orders.map((order) => (
                  <div key={order._id} className="bg-white rounded-lg shadow-md p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <p className="font-semibold text-lg">Order #{order._id.slice(-8)}</p>
                        <p className="text-sm text-gray-500">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </p>
                        <p className="text-sm">Buyer: {order.userId?.name}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-xl">${order.totalAmount.toFixed(2)}</p>
                        <div className="mt-2">
                          <select
                            value={order.status}
                            onChange={(e) => handleOrderStatusUpdate(order._id, e.target.value)}
                            className={`px-3 py-1 rounded text-sm ${
                              order.status === 'Delivered'
                                ? 'bg-green-100 text-green-800'
                                : order.status === 'Shipped'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}
                          >
                            <option value="Placed">Placed</option>
                            <option value="Shipped">Shipped</option>
                            <option value="Delivered">Delivered</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div className="border-t pt-4">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between mb-2">
                          <span>{item.productId?.title}</span>
                          <span>
                            {item.quantity} × ${item.unitPrice} = $
                            {(item.quantity * item.unitPrice).toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <Pagination currentPage={page} totalPages={totalPages} onPageChange={setPage} />
            </>
          )}
        </>
      )}

      {activeTab === 'returns' && (
        <>
          <h2 className="text-2xl font-bold mb-6">Return/Replace Requests</h2>
          {loading ? (
            <div className="text-center py-12">Loading...</div>
          ) : returns.length === 0 ? (
            <div className="text-center py-12 text-gray-500">No return/replace requests found</div>
          ) : (
            <div className="space-y-4">
              {returns.map((returnReq) => (
                <div key={returnReq._id} className="bg-white rounded-lg shadow-md p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <p className="font-semibold text-lg">
                        {returnReq.type === 'return' ? 'Return' : 'Replace'} Request
                      </p>
                      <p className="text-sm text-gray-500">
                        Order #{returnReq.orderId?._id?.slice(-8) || returnReq.orderId?.slice(-8)}
                      </p>
                      <p className="text-sm">Buyer: {returnReq.userId?.name}</p>
                      <p className="text-sm text-gray-600">
                        Requested: {new Date(returnReq.requestDate).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <span
                        className={`inline-block px-3 py-1 rounded text-sm ${
                          returnReq.status === 'approved'
                            ? 'bg-green-100 text-green-800'
                            : returnReq.status === 'rejected'
                            ? 'bg-red-100 text-red-800'
                            : returnReq.status === 'completed'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {returnReq.status}
                      </span>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <h3 className="font-semibold mb-2">Items:</h3>
                    <div className="space-y-2">
                      {returnReq.items.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <img
                              src={item.productId?.images?.[0]?.startsWith('/uploads') 
                                ? `${BASE_URL}${item.productId.images[0]}` 
                                : (item.productId?.images?.[0] || 'https://via.placeholder.com/50')}
                              alt={item.productId?.title}
                              className="w-16 h-16 object-cover rounded"
                            />
                            <div>
                              <p className="font-semibold">{item.productId?.title}</p>
                              <p className="text-sm text-gray-500">Quantity: {item.quantity}</p>
                              <p className="text-sm text-gray-600">Reason: {item.reason}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {returnReq.status === 'pending' && (
                    <div className="border-t pt-4 mt-4">
                      <div className="flex space-x-2">
                        <button
                          onClick={async () => {
                            if (!window.confirm('Approve this return/replace request?')) return;
                            try {
                              await updateReturnStatus(returnReq._id, 'approved', 'Return approved');
                              fetchReturns();
                            } catch (error) {
                              alert(error.response?.data?.message || 'Error updating status');
                            }
                          }}
                          className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
                        >
                          Approve
                        </button>
                        <button
                          onClick={async () => {
                            const response = window.prompt('Enter rejection reason:');
                            if (response) {
                              try {
                                await updateReturnStatus(returnReq._id, 'rejected', response);
                                fetchReturns();
                              } catch (error) {
                                alert(error.response?.data?.message || 'Error updating status');
                              }
                            }
                          }}
                          className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  )}

                  {returnReq.status === 'approved' && (
                    <div className="border-t pt-4 mt-4">
                      <button
                        onClick={async () => {
                          try {
                            await updateReturnStatus(returnReq._id, 'completed', 'Return completed');
                            fetchReturns();
                          } catch (error) {
                            alert(error.response?.data?.message || 'Error updating status');
                          }
                        }}
                        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
                      >
                        Mark as Completed
                      </button>
                    </div>
                  )}

                  {returnReq.sellerResponse && (
                    <div className="border-t pt-4 mt-4">
                      <p className="text-sm text-gray-600">
                        <strong>Your Response:</strong> {returnReq.sellerResponse}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default SellerDashboard;
