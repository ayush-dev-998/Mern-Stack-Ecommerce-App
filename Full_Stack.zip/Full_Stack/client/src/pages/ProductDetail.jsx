import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getProduct, addReview } from '../api/products';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { BASE_URL } from '../api/axios';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { addToCart } = useCart();
  const { addItem, removeItem, isInWishlist } = useWishlist();
  const [product, setProduct] = useState(null);
  const inWishlist = product ? isInWishlist(product._id) : false;
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '' });
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [userReview, setUserReview] = useState(null);

  useEffect(() => {
    fetchProduct();
  }, [id, user?._id]);

  const fetchProduct = async () => {
    setLoading(true);
    try {
      const response = await getProduct(id);
      setProduct(response.data.product);
      setReviews(response.data.reviews || []);
      
      // Find user's review if logged in
      if (user) {
        const myReview = response.data.reviews?.find(r => r.userId._id === user._id);
        if (myReview) {
          setUserReview(myReview);
          setReviewForm({ rating: myReview.rating, comment: myReview.comment || '' });
        } else {
          setUserReview(null);
          setReviewForm({ rating: 5, comment: '' });
        }
      }
    } catch (error) {
      console.error('Error fetching product:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async () => {
    if (!user) {
      navigate('/login');
      return;
    }

    try {
      await addToCart(product._id, quantity);
      alert('Product added to cart!');
    } catch (error) {
      alert(error.response?.data?.message || 'Error adding to cart');
    }
  };

  const handleSubmitReview = async (e) => {
    e.preventDefault();
    if (!user) {
      navigate('/login');
      return;
    }

    try {
      const response = await addReview(id, reviewForm);
      alert(userReview ? 'Review updated successfully!' : 'Review submitted!');
      setShowReviewForm(false);
      fetchProduct();
    } catch (error) {
      alert(error.response?.data?.message || 'Error submitting review');
    }
  };

  if (loading) {
    return <div className="container mx-auto px-4 py-8 text-center">Loading...</div>;
  }

  if (!product) {
    return <div className="container mx-auto px-4 py-8 text-center">Product not found</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Images */}
        <div>
          <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden mb-4">
            <img
              src={product.images?.[0]?.startsWith('/uploads') ? `${BASE_URL}${product.images[0]}` : (product.images?.[0] || 'https://via.placeholder.com/600')}
              alt={product.title}
              className="w-full h-full object-cover"
            />
          </div>
          {product.images?.length > 1 && (
            <div className="grid grid-cols-4 gap-2">
              {product.images.slice(1, 5).map((img, idx) => (
                <img
                  key={idx}
                  src={img?.startsWith('/uploads') ? `${BASE_URL}${img}` : img}
                  alt={`${product.title} ${idx + 2}`}
                  className="w-full aspect-square object-cover rounded"
                />
              ))}
            </div>
          )}
        </div>

        {/* Product Info */}
        <div>
          <h1 className="text-3xl font-bold mb-4">{product.title}</h1>
          <div className="flex items-center mb-4">
            {product.ratingAvg > 0 && (
              <>
                <span className="text-yellow-500 text-2xl">★</span>
                <span className="ml-2 text-xl">{product.ratingAvg.toFixed(1)}</span>
                <span className="ml-2 text-gray-600">({reviews.length} reviews)</span>
              </>
            )}
          </div>
          <p className="text-3xl font-bold text-blue-600 mb-4">${product.price}</p>
          <p className="text-gray-700 mb-6">{product.description}</p>

          <div className="mb-6">
            <label className="block mb-2">Quantity:</label>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="px-4 py-2 bg-gray-200 rounded"
              >
                -
              </button>
              <span className="text-xl">{quantity}</span>
              <button
                onClick={() => setQuantity(Math.min(product.inventoryCount, quantity + 1))}
                className="px-4 py-2 bg-gray-200 rounded"
                disabled={quantity >= product.inventoryCount}
              >
                +
              </button>
            </div>
            <p className="text-sm text-gray-600 mt-2">
              {product.inventoryCount} available
            </p>
          </div>

          {product.inventoryCount > 0 ? (
            <div className="flex space-x-3">
              <button
                onClick={handleAddToCart}
                className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 text-lg font-semibold"
              >
                Add to Cart
              </button>
              {user && user.role === 'buyer' && (
                <button
                  onClick={async () => {
                    try {
                      if (inWishlist) {
                        await removeItem(product._id);
                        alert('Removed from wishlist');
                      } else {
                        await addItem(product._id);
                        alert('Added to wishlist');
                      }
                    } catch (error) {
                      alert(error.response?.data?.message || 'Error updating wishlist');
                    }
                  }}
                  className={`px-6 py-3 rounded-lg text-lg ${
                    inWishlist
                      ? 'bg-red-500 text-white hover:bg-red-600'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  {inWishlist ? '❤️' : '🤍'}
                </button>
              )}
            </div>
          ) : (
            <div>
              <button
                disabled
                className="w-full bg-gray-400 text-white py-3 rounded-lg cursor-not-allowed"
              >
                Out of Stock
              </button>
              {user && user.role === 'buyer' && (
                <p className="text-red-500 text-sm mt-2 text-center">
                  This product is currently out of stock. You cannot add it to cart or wishlist.
                </p>
              )}
            </div>
          )}

          <div className="mt-6 p-4 bg-gray-50 rounded">
            <p className="font-semibold">Seller: {product.sellerId?.name}</p>
            <p className="text-sm text-gray-600">Category: {product.categoryId?.name}</p>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="mt-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Reviews ({reviews.length})</h2>
          {user && user.role === 'buyer' && (
            <button
              onClick={() => {
                setShowReviewForm(!showReviewForm);
                if (!showReviewForm && userReview) {
                  setReviewForm({ rating: userReview.rating, comment: userReview.comment || '' });
                } else if (!showReviewForm) {
                  setReviewForm({ rating: 5, comment: '' });
                }
              }}
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              {showReviewForm ? 'Cancel' : (userReview ? 'Edit Review' : 'Add Review')}
            </button>
          )}
        </div>

        {showReviewForm && (
          <form onSubmit={handleSubmitReview} className="bg-white p-6 rounded-lg shadow-md mb-6">
            <h3 className="text-lg font-semibold mb-4">
              {userReview ? 'Edit Your Review' : 'Write a Review'}
            </h3>
            <div className="mb-4">
              <label className="block mb-2 font-semibold">Rating (1-5 stars):</label>
              <div className="flex items-center space-x-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setReviewForm({ ...reviewForm, rating: star })}
                    className={`text-3xl ${
                      star <= reviewForm.rating ? 'text-yellow-500' : 'text-gray-300'
                    } hover:text-yellow-400 transition-colors`}
                  >
                    ★
                  </button>
                ))}
                <span className="ml-2 text-gray-600">({reviewForm.rating} out of 5)</span>
              </div>
            </div>
            <div className="mb-4">
              <label className="block mb-2 font-semibold">Review Description:</label>
              <textarea
                value={reviewForm.comment}
                onChange={(e) => setReviewForm({ ...reviewForm, comment: e.target.value })}
                className="w-full border rounded px-4 py-2"
                rows="4"
                placeholder="Share your experience with this product..."
              />
            </div>
            <button
              type="submit"
              className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
            >
              {userReview ? 'Update Review' : 'Submit Review'}
            </button>
          </form>
        )}

        {reviews.length === 0 ? (
          <p className="text-gray-500">No reviews yet. Be the first to review this product!</p>
        ) : (
          <div className="space-y-4">
            {reviews.map((review) => (
              <div key={review._id} className="bg-white p-4 rounded-lg shadow">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-semibold">
                      {review.userId?.name?.charAt(0).toUpperCase() || 'U'}
                    </div>
                    <div>
                      <span className="font-semibold text-lg">{review.userId?.name || 'Anonymous'}</span>
                      <p className="text-sm text-gray-500">
                        {new Date(review.createdAt).toLocaleDateString('en-US', { 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}
                        {review.updatedAt && review.updatedAt !== review.createdAt && (
                          <span className="ml-2 text-xs">(edited)</span>
                        )}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <span
                        key={star}
                        className={`text-xl ${
                          star <= review.rating ? 'text-yellow-500' : 'text-gray-300'
                        }`}
                      >
                        ★
                      </span>
                    ))}
                    <span className="ml-2 font-semibold">{review.rating}.0</span>
                  </div>
                </div>
                {review.comment && (
                  <p className="text-gray-700 mt-3 leading-relaxed">{review.comment}</p>
                )}
                {!review.comment && (
                  <p className="text-gray-400 italic mt-3">No description provided</p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;

