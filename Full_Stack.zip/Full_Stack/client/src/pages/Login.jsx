import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { login, forgotPassword, resetPassword } from '../api/auth';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

const Login = () => {
  const navigate = useNavigate();
  const { login: setAuth } = useAuth();
  const { syncGuestCart } = useCart();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotPasswordData, setForgotPasswordData] = useState({
    email: '',
    otp: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [otpSent, setOtpSent] = useState(false);
  const [forgotPasswordLoading, setForgotPasswordLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await login(formData);
      setAuth(response.data, response.data.token);
      await syncGuestCart();
      
      // Redirect based on role
      if (response.data.role === 'admin') {
        navigate('/admin/dashboard');
      } else if (response.data.role === 'seller') {
        navigate('/seller/dashboard');
      } else {
        navigate('/');
      }
    } catch (error) {
      setError(error.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-lg shadow-md">
        <div>
          <h2 className="text-center text-3xl font-bold">Login</h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Or{' '}
            <Link to="/register" className="text-blue-600 hover:text-blue-500">
              create a new account
            </Link>
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
              {error}
            </div>
          )}
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">
              Email address
            </label>
            <input
              id="email"
              name="email"
              type="email"
              required
              value={formData.email}
              onChange={handleChange}
              className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">
              Password
            </label>
            <input
              id="password"
              name="password"
              type="password"
              required
              value={formData.password}
              onChange={handleChange}
              className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
            />
          </div>
          <div>
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              {loading ? 'Logging in...' : 'Login'}
            </button>
          </div>
          <div className="text-center">
            <button
              type="button"
              onClick={() => setShowForgotPassword(true)}
              className="text-sm text-blue-600 hover:text-blue-500"
            >
              Forgot Password?
            </button>
          </div>
        </form>

        {showForgotPassword && (
          <div className="mt-6 p-6 bg-gray-50 rounded-lg">
            <h3 className="text-xl font-bold mb-4">Reset Password</h3>
            {!otpSent ? (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  setForgotPasswordLoading(true);
                  setError('');
                  try {
                    await forgotPassword(forgotPasswordData.email);
                    setOtpSent(true);
                    alert('OTP sent to your email address');
                  } catch (error) {
                    setError(error.response?.data?.message || 'Error sending OTP');
                  } finally {
                    setForgotPasswordLoading(false);
                  }
                }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email address
                  </label>
                  <input
                    type="email"
                    required
                    value={forgotPasswordData.email}
                    onChange={(e) =>
                      setForgotPasswordData({ ...forgotPasswordData, email: e.target.value })
                    }
                    className="w-full border border-gray-300 rounded-md px-3 py-2"
                  />
                </div>
                <button
                  type="submit"
                  disabled={forgotPasswordLoading}
                  className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {forgotPasswordLoading ? 'Sending...' : 'Send OTP'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowForgotPassword(false);
                    setOtpSent(false);
                    setForgotPasswordData({ email: '', otp: '', newPassword: '', confirmPassword: '' });
                  }}
                  className="w-full bg-gray-200 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-300"
                >
                  Cancel
                </button>
              </form>
            ) : (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (forgotPasswordData.newPassword !== forgotPasswordData.confirmPassword) {
                    setError('Passwords do not match');
                    return;
                  }
                  if (forgotPasswordData.newPassword.length < 6) {
                    setError('Password must be at least 6 characters long');
                    return;
                  }
                  setForgotPasswordLoading(true);
                  setError('');
                  try {
                    await resetPassword(
                      forgotPasswordData.email,
                      forgotPasswordData.otp,
                      forgotPasswordData.newPassword
                    );
                    alert('Password reset successfully! Please login with your new password.');
                    setShowForgotPassword(false);
                    setOtpSent(false);
                    setForgotPasswordData({ email: '', otp: '', newPassword: '', confirmPassword: '' });
                  } catch (error) {
                    setError(error.response?.data?.message || 'Error resetting password');
                  } finally {
                    setForgotPasswordLoading(false);
                  }
                }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Enter OTP
                  </label>
                  <input
                    type="text"
                    required
                    maxLength="6"
                    value={forgotPasswordData.otp}
                    onChange={(e) =>
                      setForgotPasswordData({ ...forgotPasswordData, otp: e.target.value })
                    }
                    className="w-full border border-gray-300 rounded-md px-3 py-2"
                    placeholder="6-digit OTP"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    New Password
                  </label>
                  <input
                    type="password"
                    required
                    value={forgotPasswordData.newPassword}
                    onChange={(e) =>
                      setForgotPasswordData({ ...forgotPasswordData, newPassword: e.target.value })
                    }
                    className="w-full border border-gray-300 rounded-md px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    required
                    value={forgotPasswordData.confirmPassword}
                    onChange={(e) =>
                      setForgotPasswordData({ ...forgotPasswordData, confirmPassword: e.target.value })
                    }
                    className="w-full border border-gray-300 rounded-md px-3 py-2"
                  />
                </div>
                <button
                  type="submit"
                  disabled={forgotPasswordLoading}
                  className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {forgotPasswordLoading ? 'Resetting...' : 'Reset Password'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setOtpSent(false);
                    setForgotPasswordData({ ...forgotPasswordData, otp: '', newPassword: '', confirmPassword: '' });
                  }}
                  className="w-full bg-gray-200 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-300"
                >
                  Resend OTP
                </button>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Login;

