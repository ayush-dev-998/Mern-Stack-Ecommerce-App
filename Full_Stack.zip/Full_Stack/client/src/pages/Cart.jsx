import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { getProduct } from '../api/products';

const Cart = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { cart, updateCartItem, removeItem, getCartTotal, getDeliveryFee, getGrandTotal, emptyCart } = useCart();
  const [cartProducts, setCartProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchCartProducts();
    }
  }, [cart, user]);

  const fetchCartProducts = async () => {
    if (!cart.items || cart.items.length === 0) {
      setCartProducts([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      const products = await Promise.all(
        cart.items.map(async (item) => {
          try {
            // Handle both string ID (guest) and object ID (logged in)
            const productId = typeof item.productId === 'string' 
              ? item.productId 
              : item.productId._id || item.productId;
            
            // If product is already populated, use it
            if (item.productId && typeof item.productId === 'object' && item.productId.title) {
              return {
                ...item,
                product: item.productId,
              };
            }
            
            const response = await getProduct(productId);
            return {
              ...item,
              product: response.data.product,
            };
          } catch (error) {
            console.error('Error fetching product:', error);
            return null;
          }
        })
      );
      setCartProducts(products.filter(Boolean));
    } catch (error) {
      console.error('Error fetching cart products:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleQuantityChange = async (item, newQuantity) => {
    // Extract productId - handle both string and object
    const productId = typeof item.productId === 'string' 
      ? item.productId 
      : item.productId._id || item.productId;
    
    if (newQuantity < 1) {
      await removeItem(productId);
    } else {
      await updateCartItem(productId, newQuantity);
    }
  };

  const handleCheckout = () => {
    if (!user) {
      navigate('/login');
      return;
    }
    navigate('/checkout');
  };

  const handleEmptyCart = async () => {
    if (!window.confirm('Are you sure you want to empty your cart?')) return;
    try {
      await emptyCart();
      alert('Cart emptied successfully');
    } catch (error) {
      alert(error.response?.data?.message || 'Error emptying cart');
    }
  };

  if (loading) {
    return <div className="container mx-auto px-4 py-8 text-center">Loading...</div>;
  }

  if (cartProducts.length === 0) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Shopping Cart</h1>
        <div className="text-center py-12">
          <p className="text-gray-500 text-xl mb-4">Your cart is empty</p>
          <button
            onClick={() => navigate('/')}
            className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Shopping Cart</h1>
        <button
          onClick={handleEmptyCart}
          className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
        >
          Empty Cart
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md">
            {cartProducts.map((item) => (
              <div
                key={item.productId}
                className="flex items-center p-4 border-b last:border-b-0"
              >
                <img
                  src={item.product.images?.[0]?.startsWith('/uploads') ? `http://localhost:5000${item.product.images[0]}` : (item.product.images?.[0] || 'https://via.placeholder.com/100')}
                  alt={item.product.title}
                  className="w-24 h-24 object-cover rounded"
                />
                <div className="flex-1 ml-4">
                  <h3 className="font-semibold text-lg">{item.product.title}</h3>
                  <p className="text-gray-600">${item.priceAtAdd || item.product.price}</p>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleQuantityChange(item, item.quantity - 1)}
                      className="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300"
                    >
                      -
                    </button>
                    <span className="w-12 text-center font-semibold">{item.quantity}</span>
                    <button
                      onClick={() => handleQuantityChange(item, item.quantity + 1)}
                      className="px-3 py-1 bg-gray-200 rounded hover:bg-gray-300"
                      disabled={item.quantity >= item.product.inventoryCount}
                    >
                      +
                    </button>
                  </div>
                  <p className="font-semibold w-24 text-right">
                    ${((item.priceAtAdd || item.product.price) * item.quantity).toFixed(2)}
                  </p>
                  <button
                    onClick={() => {
                      const productId = typeof item.productId === 'string' 
                        ? item.productId 
                        : item.productId._id || item.productId;
                      removeItem(productId);
                    }}
                    className="text-red-500 hover:text-red-700 ml-4"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6 sticky top-20">
            <h2 className="text-2xl font-bold mb-4">Order Summary</h2>
            <div className="space-y-2 mb-4">
              <div className="flex justify-between">
                <span>Subtotal ({cartProducts.reduce((sum, item) => sum + item.quantity, 0)} items):</span>
                <span>${getCartTotal().toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Fee:</span>
                <span>${getDeliveryFee().toFixed(2)}</span>
              </div>
              <div className="border-t pt-2 flex justify-between font-bold text-xl">
                <span>Total:</span>
                <span>${getGrandTotal().toFixed(2)}</span>
              </div>
            </div>
            <button
              onClick={handleCheckout}
              className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 text-lg font-semibold"
            >
              Proceed to Checkout
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
