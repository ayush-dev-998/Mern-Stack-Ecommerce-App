const TermsAndConditions = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-6">Terms and Conditions</h1>
      
      <div className="bg-white rounded-lg shadow-md p-8 space-y-6">
        <section>
          <h2 className="text-2xl font-semibold mb-4">1. Acceptance of Terms</h2>
          <p className="text-gray-700 leading-relaxed">
            By accessing and using this website, you accept and agree to be bound by the terms and 
            provision of this agreement. If you do not agree to abide by the above, please do not 
            use this service.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">2. Use License</h2>
          <p className="text-gray-700 leading-relaxed">
            Permission is granted to temporarily download one copy of the materials on our website 
            for personal, non-commercial transitory viewing only. This is the grant of a license, 
            not a transfer of title.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">3. User Accounts</h2>
          <p className="text-gray-700 leading-relaxed">
            You are responsible for maintaining the confidentiality of your account and password. 
            You agree to accept responsibility for all activities that occur under your account.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">4. Product Information</h2>
          <p className="text-gray-700 leading-relaxed">
            We strive to provide accurate product descriptions and pricing. However, we do not 
            warrant that product descriptions or other content is accurate, complete, reliable, 
            current, or error-free.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">5. Payment Terms</h2>
          <p className="text-gray-700 leading-relaxed">
            All payments must be made through approved payment methods. We reserve the right to 
            refuse or cancel any order at any time for reasons including but not limited to product 
            availability, errors in pricing, or fraud prevention.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">6. Limitation of Liability</h2>
          <p className="text-gray-700 leading-relaxed">
            In no event shall our company or its suppliers be liable for any damages arising out of 
            the use or inability to use the materials on our website.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">7. Revisions</h2>
          <p className="text-gray-700 leading-relaxed">
            We may revise these terms of service at any time without notice. By using this website 
            you are agreeing to be bound by the then current version of these terms of service.
          </p>
        </section>

        <section>
          <p className="text-sm text-gray-500 mt-8">
            Last updated: {new Date().toLocaleDateString()}
          </p>
        </section>
      </div>
    </div>
  );
};

export default TermsAndConditions;

