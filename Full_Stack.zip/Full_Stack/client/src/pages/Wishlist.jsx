import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { BASE_URL } from '../api/axios';
import { Link } from 'react-router-dom';

const Wishlist = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { wishlist, removeItem, emptyWishlistItems, loading: wishlistLoading } = useWishlist();
  const { addToCart } = useCart();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(false);
  }, [wishlist]);

  const handleAddToCart = async (productId) => {
    if (!user) {
      navigate('/login');
      return;
    }
    try {
      await addToCart(productId, 1);
      alert('Product added to cart!');
    } catch (error) {
      alert(error.response?.data?.message || 'Error adding to cart');
    }
  };

  const handleRemoveItem = async (productId) => {
    try {
      await removeItem(productId);
    } catch (error) {
      alert(error.response?.data?.message || 'Error removing from wishlist');
    }
  };

  const handleEmptyWishlist = async () => {
    if (!window.confirm('Are you sure you want to empty your wishlist?')) return;
    try {
      await emptyWishlistItems();
      alert('Wishlist emptied successfully');
    } catch (error) {
      alert(error.response?.data?.message || 'Error emptying wishlist');
    }
  };

  if (wishlistLoading || loading) {
    return <div className="container mx-auto px-4 py-8 text-center">Loading...</div>;
  }

  if (!wishlist.items || wishlist.items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">My Wishlist</h1>
        <div className="text-center py-12">
          <p className="text-gray-500 text-xl mb-4">Your wishlist is empty</p>
          <button
            onClick={() => navigate('/')}
            className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">My Wishlist ({wishlist.items.length})</h1>
        <button
          onClick={handleEmptyWishlist}
          className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
        >
          Empty Wishlist
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {wishlist.items.map((item) => {
          const product = item.productId;
          if (!product) return null;

          return (
            <div key={item._id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow relative">
              <Link to={`/product/${product._id}`}>
                <div className="aspect-square overflow-hidden">
                  <img
                    src={product.images?.[0]?.startsWith('/uploads') ? `${BASE_URL}${product.images[0]}` : (product.images?.[0] || 'https://via.placeholder.com/400')}
                    alt={product.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-lg mb-2 line-clamp-2">{product.title}</h3>
                  <p className="text-2xl font-bold text-blue-600">${product.price}</p>
                  {product.ratingAvg > 0 && (
                    <div className="flex items-center mt-2">
                      <span className="text-yellow-500">★</span>
                      <span className="ml-1 text-sm">{product.ratingAvg.toFixed(1)}</span>
                    </div>
                  )}
                </div>
              </Link>
              <div className="absolute top-2 right-2">
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    handleRemoveItem(product._id);
                  }}
                  className="p-2 bg-red-500 text-white rounded-full shadow-lg hover:bg-red-600"
                  title="Remove from wishlist"
                >
                  ❌
                </button>
              </div>
              <div className="p-4 pt-0">
                {product.inventoryCount > 0 ? (
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      handleAddToCart(product._id);
                    }}
                    className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
                  >
                    Add to Cart
                  </button>
                ) : (
                  <button
                    disabled
                    className="w-full bg-gray-400 text-white py-2 rounded cursor-not-allowed"
                  >
                    Out of Stock
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Wishlist;

