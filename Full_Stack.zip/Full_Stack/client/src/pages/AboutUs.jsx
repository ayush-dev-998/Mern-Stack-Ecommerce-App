const AboutUs = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-6">About Us</h1>
      
      <div className="bg-white rounded-lg shadow-md p-8 space-y-6">
        <section>
          <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
          <p className="text-gray-700 leading-relaxed">
            We are committed to providing a seamless and enjoyable shopping experience for our customers. 
            Our platform connects buyers with quality products from trusted sellers, ensuring transparency, 
            reliability, and customer satisfaction.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Who We Are</h2>
          <p className="text-gray-700 leading-relaxed">
            Founded with a vision to revolutionize online shopping, we have grown into a trusted e-commerce 
            platform serving thousands of customers. We believe in building lasting relationships with both 
            our buyers and sellers.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Our Values</h2>
          <ul className="list-disc list-inside space-y-2 text-gray-700">
            <li>Customer First: Your satisfaction is our priority</li>
            <li>Quality Assurance: We ensure all products meet high standards</li>
            <li>Transparency: Clear policies and honest communication</li>
            <li>Innovation: Continuously improving our platform</li>
            <li>Trust: Building reliable relationships with all stakeholders</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Contact Information</h2>
          <div className="space-y-2 text-gray-700">
            <p><strong>Email:</strong> support@ecommerce.com</p>
            <p><strong>Phone:</strong> 1-800-ECOM-123</p>
            <p><strong>Address:</strong> 123 Commerce Street, Business City, BC 12345</p>
            <p><strong>Business Hours:</strong> Monday - Friday, 9 AM - 6 PM EST</p>
          </div>
        </section>
      </div>
    </div>
  );
};

export default AboutUs;

