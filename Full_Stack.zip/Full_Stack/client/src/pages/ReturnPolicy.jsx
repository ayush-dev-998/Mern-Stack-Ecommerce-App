const ReturnPolicy = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-6">Return & Exchange Policy</h1>
      
      <div className="bg-white rounded-lg shadow-md p-8 space-y-6">
        <section>
          <h2 className="text-2xl font-semibold mb-4">Return/Exchange Window</h2>
          <p className="text-gray-700 leading-relaxed">
            You can return or exchange items within <strong>7 days</strong> of delivery. 
            The return/exchange request must be initiated before the 7-day period expires.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Eligibility</h2>
          <ul className="list-disc list-inside space-y-2 text-gray-700">
            <li>Only delivered orders are eligible for return/exchange</li>
            <li>Items must be in original condition with tags attached</li>
            <li>Items must not be used, damaged, or altered</li>
            <li>Original packaging should be retained when possible</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">How to Return/Exchange</h2>
          <ol className="list-decimal list-inside space-y-2 text-gray-700">
            <li>Go to your Orders page</li>
            <li>Select the delivered order you want to return/exchange</li>
            <li>Click on "Return/Replace" button</li>
            <li>Select the items and provide reason</li>
            <li>Submit your request</li>
            <li>Wait for seller approval</li>
          </ol>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Return Reasons</h2>
          <p className="text-gray-700 leading-relaxed mb-2">
            Common reasons for return/exchange include:
          </p>
          <ul className="list-disc list-inside space-y-2 text-gray-700">
            <li>Defective or damaged product</li>
            <li>Wrong item received</li>
            <li>Size/color mismatch</li>
            <li>Product not as described</li>
            <li>Changed mind (subject to seller approval)</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Refund Process</h2>
          <p className="text-gray-700 leading-relaxed">
            Once your return is approved and processed:
          </p>
          <ul className="list-disc list-inside space-y-2 text-gray-700 mt-2">
            <li>Refunds will be processed within 5-7 business days</li>
            <li>Refund will be credited to your original payment method</li>
            <li>For cash on delivery, refund will be processed via bank transfer</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Non-Returnable Items</h2>
          <ul className="list-disc list-inside space-y-2 text-gray-700">
            <li>Personalized or customized products</li>
            <li>Perishable goods</li>
            <li>Items without original packaging</li>
            <li>Products damaged by customer misuse</li>
          </ul>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Exchange Process</h2>
          <p className="text-gray-700 leading-relaxed">
            For exchanges, the seller will review your request and may approve or suggest alternatives. 
            Once approved, a replacement item will be shipped to you.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Contact for Issues</h2>
          <p className="text-gray-700 leading-relaxed">
            If you face any issues with returns or exchanges, please contact our support team at 
            <strong> support@ecommerce.com</strong> or call <strong>1-800-ECOM-123</strong>.
          </p>
        </section>
      </div>
    </div>
  );
};

export default ReturnPolicy;

