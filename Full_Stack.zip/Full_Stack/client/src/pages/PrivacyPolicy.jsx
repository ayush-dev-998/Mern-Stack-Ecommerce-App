const PrivacyPolicy = () => {
  return (
    <section className="max-w-4xl mx-auto p-6 bg-white rounded-2xl shadow-sm">
      <h1 className="text-3xl font-semibold mb-4">Privacy Policy</h1>
      <p className="text-sm text-gray-600 mb-6">
        This Privacy Policy explains how <strong>YourStore</strong> collects,
        uses, and protects your information when you use our website and
        services.
      </p>

      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-medium">1. Information We Collect</h2>
          <ul className="list-disc pl-6 mt-2 text-gray-700">
            <li>Account information (name, email, phone).</li>
            <li>Shipping & billing addresses.</li>
            <li>Order history and transaction details.</li>
            <li>Device and usage data (cookies, IP address, browser info).</li>
          </ul>
        </div>

        <div>
          <h2 className="text-xl font-medium">2. How We Use Your Information</h2>
          <p className="mt-2 text-gray-700">We use collected information to:</p>
          <ul className="list-disc pl-6 mt-2 text-gray-700">
            <li>Process orders, manage accounts and provide customer support.</li>
            <li>Send transactional emails like order updates.</li>
            <li>Improve our website and personalize recommendations.</li>
            <li>Prevent fraud and ensure security of your data.</li>
          </ul>
        </div>

        <div>
          <h2 className="text-xl font-medium">3. Sharing & Disclosure</h2>
          <p className="mt-2 text-gray-700">
            We do not sell your personal information. We may share data with:
          </p>
          <ul className="list-disc pl-6 mt-2 text-gray-700">
            <li>Payment processors.</li>
            <li>Shipping carriers.</li>
            <li>Service providers like hosting & analytics partners.</li>
          </ul>
        </div>

        <div>
          <h2 className="text-xl font-medium">4. Cookies & Tracking</h2>
          <p className="mt-2 text-gray-700">
            We use cookies for authentication, analytics, and personalization.
          </p>
        </div>

        <div>
          <h2 className="text-xl font-medium">5. Data Security</h2>
          <p className="mt-2 text-gray-700">
            We use industry-standard measures to protect your information, but
            no method is 100% secure.
          </p>
        </div>

        <div>
          <h2 className="text-xl font-medium">6. Your Rights</h2>
          <p className="mt-2 text-gray-700">
            Depending on your region, you may request access, correction, or
            deletion of your data.
          </p>
        </div>

        <div>
          <h2 className="text-xl font-medium">7. Contact Us</h2>
          <p className="mt-2 text-gray-700">
            For privacy questions, email{" "}
            <a href="mailto:support@yourstore.com" className="text-blue-600">
              support@yourstore.com
            </a>
          </p>
        </div>
      </div>
    </section>
  );
};

export default PrivacyPolicy;
