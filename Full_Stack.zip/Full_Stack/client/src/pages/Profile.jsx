import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { updateProfile } from '../api/auth';

const Profile = () => {
  const { user, fetchUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: {
      street: '',
      city: '',
      state: '',
      zipCode: '',
      country: '',
    },
    sellerProfile: {
      storeName: '',
      description: '',
      phone: '',
      gstNumber: '',
      address: {
        street: '',
        city: '',
        state: '',
        zipCode: '',
        country: '',
      },
    },
  });

  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || '',
        phone: user.profile?.phone || '',
        address: {
          street: user.profile?.address?.street || '',
          city: user.profile?.address?.city || '',
          state: user.profile?.address?.state || '',
          zipCode: user.profile?.address?.zipCode || '',
          country: user.profile?.address?.country || '',
        },
        sellerProfile: {
          storeName: user.sellerProfile?.storeName || '',
          description: user.sellerProfile?.description || '',
          phone: user.sellerProfile?.phone || '',
          gstNumber: user.sellerProfile?.gstNumber || '',
          address: {
            street: user.sellerProfile?.address?.street || '',
            city: user.sellerProfile?.address?.city || '',
            state: user.sellerProfile?.address?.state || '',
            zipCode: user.sellerProfile?.address?.zipCode || '',
            country: user.sellerProfile?.address?.country || '',
          },
        },
      });
    }
  }, [user]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.startsWith('address.')) {
      const field = name.split('.')[1];
      setFormData({
        ...formData,
        address: { ...formData.address, [field]: value },
      });
    } else if (name.startsWith('sellerProfile.')) {
      const parts = name.split('.');
      if (parts.length === 2) {
        // sellerProfile.field
        const field = parts[1];
        setFormData({
          ...formData,
          sellerProfile: { ...formData.sellerProfile, [field]: value },
        });
      } else if (parts.length === 3 && parts[1] === 'address') {
        // sellerProfile.address.field
        const field = parts[2];
        setFormData({
          ...formData,
          sellerProfile: {
            ...formData.sellerProfile,
            address: { ...formData.sellerProfile.address, [field]: value },
          },
        });
      }
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      // Only send address if it's not empty
      const dataToSend = { ...formData };
      if (user.role === 'seller') {
        // For sellers, only send sellerProfile, not address
        dataToSend.address = undefined;
      } else {
        // For buyers, only send address, not sellerProfile
        dataToSend.sellerProfile = undefined;
      }
      await updateProfile(dataToSend);
      await fetchUser();
      alert('Profile updated successfully!');
    } catch (error) {
      alert(error.response?.data?.message || 'Error updating profile');
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return <div className="container mx-auto px-4 py-8 text-center">Loading...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">
        {user.role === 'seller' ? 'Seller Profile' : 'My Profile'}
      </h1>

      <div className="bg-white rounded-lg shadow-md p-6 max-w-2xl">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block mb-2 font-semibold">Name *</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              className="w-full border rounded px-4 py-2"
            />
          </div>

          <div>
            <label className="block mb-2 font-semibold">Email</label>
            <input
              type="email"
              value={user.email}
              disabled
              className="w-full border rounded px-4 py-2 bg-gray-100"
            />
            <p className="text-sm text-gray-500 mt-1">Email cannot be changed</p>
          </div>

          {user.role !== 'seller' && (
            <>
              <div>
                <label className="block mb-2 font-semibold">Phone</label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full border rounded px-4 py-2"
                />
              </div>

              <div>
                <h3 className="font-semibold mb-4">Address</h3>
            <div className="space-y-4">
              <div>
                <label className="block mb-2">Street</label>
                <input
                  type="text"
                  name="address.street"
                  value={formData.address.street}
                  onChange={handleChange}
                  className="w-full border rounded px-4 py-2"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block mb-2">City</label>
                  <input
                    type="text"
                    name="address.city"
                    value={formData.address.city}
                    onChange={handleChange}
                    className="w-full border rounded px-4 py-2"
                  />
                </div>
                <div>
                  <label className="block mb-2">State</label>
                  <input
                    type="text"
                    name="address.state"
                    value={formData.address.state}
                    onChange={handleChange}
                    className="w-full border rounded px-4 py-2"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block mb-2">Zip Code</label>
                  <input
                    type="text"
                    name="address.zipCode"
                    value={formData.address.zipCode}
                    onChange={handleChange}
                    className="w-full border rounded px-4 py-2"
                  />
                </div>
                <div>
                  <label className="block mb-2">Country</label>
                  <input
                    type="text"
                    name="address.country"
                    value={formData.address.country}
                    onChange={handleChange}
                    className="w-full border rounded px-4 py-2"
                  />
                </div>
              </div>
            </div>
          </div>
          </>
          )}

          {user.role === 'seller' && (
            <div>
              <h3 className="font-semibold mb-4">Seller Profile</h3>
              <div className="space-y-4">
                <div>
                  <label className="block mb-2">Store Name *</label>
                  <input
                    type="text"
                    name="sellerProfile.storeName"
                    value={formData.sellerProfile.storeName}
                    onChange={handleChange}
                    required
                    className="w-full border rounded px-4 py-2"
                  />
                </div>
                <div>
                  <label className="block mb-2">Store Description</label>
                  <textarea
                    name="sellerProfile.description"
                    value={formData.sellerProfile.description}
                    onChange={handleChange}
                    rows="4"
                    className="w-full border rounded px-4 py-2"
                    placeholder="Describe your store..."
                  />
                </div>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 text-lg font-semibold disabled:opacity-50"
          >
            {loading ? 'Updating...' : 'Update Profile'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Profile;

