import { useState, useEffect } from 'react';
import { getOrders, cancelOrder } from '../api/orders';
import { requestReturn, getBuyerReturns } from '../api/returns';
import Pagination from '../components/Pagination';
import { BASE_URL } from '../api/axios';

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [returns, setReturns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [showReturnForm, setShowReturnForm] = useState(null);
  const [returnForm, setReturnForm] = useState({ type: 'return', items: [] });

  useEffect(() => {
    fetchOrders();
    fetchReturns();
  }, [page]);

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const response = await getOrders({ page, limit: 10 });
      setOrders(response.data.orders);
      setTotalPages(response.data.pages);
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchReturns = async () => {
    try {
      const response = await getBuyerReturns();
      setReturns(response.data);
    } catch (error) {
      console.error('Error fetching returns:', error);
    }
  };

  const handleCancelOrder = async (orderId) => {
    if (!window.confirm('Are you sure you want to cancel this order? The stock will be restored.')) {
      return;
    }

    try {
      await cancelOrder(orderId);
      alert('Order cancelled successfully! Stock has been restored.');
      fetchOrders();
    } catch (error) {
      alert(error.response?.data?.message || 'Error cancelling order');
    }
  };

  const handleReturnRequest = async (order) => {
    // Check if order is delivered and within 7 days
    if (order.status !== 'Delivered') {
      alert('Only delivered orders can be returned/replaced');
      return;
    }

    const deliveryDate = new Date(order.updatedAt || order.createdAt);
    const daysSinceDelivery = (Date.now() - deliveryDate.getTime()) / (1000 * 60 * 60 * 24);
    
    if (daysSinceDelivery > 7) {
      alert('Return/replace request must be made within 7 days of delivery');
      return;
    }

    setShowReturnForm(order._id);
    setReturnForm({ type: 'return', items: [] });
  };

  const handleReturnSubmit = async (orderId) => {
    if (returnForm.items.length === 0) {
      alert('Please select at least one item to return/replace');
      return;
    }

    try {
      await requestReturn({
        orderId,
        items: returnForm.items,
        type: returnForm.type,
      });
      alert(`${returnForm.type === 'return' ? 'Return' : 'Replace'} request submitted successfully!`);
      setShowReturnForm(null);
      setReturnForm({ type: 'return', items: [] });
      fetchReturns();
    } catch (error) {
      alert(error.response?.data?.message || 'Error submitting return request');
    }
  };

  const toggleReturnItem = (item, order) => {
    const existingIndex = returnForm.items.findIndex(
      i => i.productId === item.productId._id || i.productId === item.productId
    );

    if (existingIndex > -1) {
      setReturnForm({
        ...returnForm,
        items: returnForm.items.filter((_, idx) => idx !== existingIndex),
      });
    } else {
      setReturnForm({
        ...returnForm,
        items: [
          ...returnForm.items,
          {
            productId: item.productId._id || item.productId,
            quantity: item.quantity,
            reason: '',
          },
        ],
      });
    }
  };

  const updateReturnReason = (productId, reason) => {
    setReturnForm({
      ...returnForm,
      items: returnForm.items.map(item =>
        (item.productId === productId || item.productId === productId._id)
          ? { ...item, reason }
          : item
      ),
    });
  };

  if (loading) {
    return <div className="container mx-auto px-4 py-8 text-center">Loading...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">My Orders</h1>

      {orders.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500 text-xl">No orders found</p>
        </div>
      ) : (
        <>
          <div className="space-y-4">
            {orders.map((order) => {
              const orderReturn = returns.find(r => r.orderId._id === order._id || r.orderId === order._id);
              const isDelivered = order.status === 'Delivered';
              const deliveryDate = isDelivered ? new Date(order.updatedAt || order.createdAt) : null;
              const daysSinceDelivery = deliveryDate 
                ? (Date.now() - deliveryDate.getTime()) / (1000 * 60 * 60 * 24)
                : null;
              const canReturn = isDelivered && daysSinceDelivery !== null && daysSinceDelivery <= 7;

              return (
                <div key={order._id} className="bg-white rounded-lg shadow-md p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <p className="font-semibold text-lg">Order #{order._id.toString().slice(-8)}</p>
                      <p className="text-sm text-gray-500">
                        {new Date(order.createdAt).toLocaleDateString()}
                      </p>
                      <p className="text-sm text-gray-600 mt-1">
                        Payment: <span className="capitalize">{order.paymentMethod}</span> - 
                        <span className={`ml-1 ${
                          order.paymentStatus === 'paid' ? 'text-green-600' : 
                          order.paymentStatus === 'pending' ? 'text-yellow-600' : 
                          'text-red-600'
                        }`}>
                          {order.paymentStatus}
                        </span>
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-xl">${order.totalAmount.toFixed(2)}</p>
                      <span
                        className={`inline-block px-3 py-1 rounded text-sm mt-2 ${
                          order.status === 'Delivered'
                            ? 'bg-green-100 text-green-800'
                            : order.status === 'Shipped'
                            ? 'bg-blue-100 text-blue-800'
                            : order.status === 'Cancelled'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {order.status}
                      </span>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <h3 className="font-semibold mb-2">Items:</h3>
                    <div className="space-y-2">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <img
                              src={item.productId?.images?.[0]?.startsWith('/uploads') 
                                ? `${BASE_URL}${item.productId.images[0]}` 
                                : (item.productId?.images?.[0] || 'https://via.placeholder.com/50')}
                              alt={item.productId?.title}
                              className="w-16 h-16 object-cover rounded"
                            />
                            <div>
                              <p className="font-semibold">{item.productId?.title}</p>
                              <p className="text-sm text-gray-500">
                                Quantity: {item.quantity} × ${item.unitPrice}
                              </p>
                            </div>
                          </div>
                          <p className="font-semibold">
                            ${(item.quantity * item.unitPrice).toFixed(2)}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="border-t pt-4 mt-4">
                    <h3 className="font-semibold mb-2">Shipping Address:</h3>
                    <p className="text-sm text-gray-600">
                      {order.shippingAddress.name}
                      <br />
                      {order.shippingAddress.street}
                      <br />
                      {order.shippingAddress.city}, {order.shippingAddress.state}{' '}
                      {order.shippingAddress.zipCode}
                      <br />
                      Phone: {order.shippingAddress.phone}
                    </p>
                  </div>

                  {orderReturn && (
                    <div className="border-t pt-4 mt-4 bg-yellow-50 p-4 rounded">
                      <h3 className="font-semibold mb-2">Return/Replace Status:</h3>
                      <p className="text-sm">
                        Type: <span className="capitalize">{orderReturn.type}</span> | 
                        Status: <span className={`font-semibold ${
                          orderReturn.status === 'approved' ? 'text-green-600' :
                          orderReturn.status === 'rejected' ? 'text-red-600' :
                          orderReturn.status === 'completed' ? 'text-blue-600' :
                          'text-yellow-600'
                        }`}>
                          {orderReturn.status}
                        </span>
                      </p>
                      {orderReturn.sellerResponse && (
                        <p className="text-sm text-gray-600 mt-1">
                          Seller Response: {orderReturn.sellerResponse}
                        </p>
                      )}
                    </div>
                  )}

                  {showReturnForm === order._id && (
                    <div className="border-t pt-4 mt-4 bg-gray-50 p-4 rounded">
                      <h3 className="font-semibold mb-4">Request Return/Replace</h3>
                      <div className="mb-4">
                        <label className="block mb-2">Type:</label>
                        <select
                          value={returnForm.type}
                          onChange={(e) => setReturnForm({ ...returnForm, type: e.target.value })}
                          className="border rounded px-4 py-2"
                        >
                          <option value="return">Return</option>
                          <option value="replace">Replace</option>
                        </select>
                      </div>
                      <div className="mb-4">
                        <label className="block mb-2">Select Items:</label>
                        {order.items.map((item, idx) => {
                          const isSelected = returnForm.items.some(
                            i => i.productId === (item.productId._id || item.productId)
                          );
                          return (
                            <div key={idx} className="mb-2">
                              <label className="flex items-center space-x-2">
                                <input
                                  type="checkbox"
                                  checked={isSelected}
                                  onChange={() => toggleReturnItem(item, order)}
                                />
                                <span>{item.productId?.title} (Qty: {item.quantity})</span>
                              </label>
                              {isSelected && (
                                <input
                                  type="text"
                                  placeholder="Reason for return/replace"
                                  value={returnForm.items.find(i => 
                                    i.productId === (item.productId._id || item.productId)
                                  )?.reason || ''}
                                  onChange={(e) => updateReturnReason(
                                    item.productId._id || item.productId,
                                    e.target.value
                                  )}
                                  className="mt-1 w-full border rounded px-3 py-2 text-sm"
                                  required
                                />
                              )}
                            </div>
                          );
                        })}
                      </div>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleReturnSubmit(order._id)}
                          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                        >
                          Submit Request
                        </button>
                        <button
                          onClick={() => {
                            setShowReturnForm(null);
                            setReturnForm({ type: 'return', items: [] });
                          }}
                          className="bg-gray-200 px-4 py-2 rounded"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="border-t pt-4 mt-4 flex space-x-2">
                    {order.status === 'Placed' && (
                      <button
                        onClick={() => handleCancelOrder(order._id)}
                        className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
                      >
                        Cancel Order
                      </button>
                    )}
                    {canReturn && !orderReturn && (
                      <button
                        onClick={() => handleReturnRequest(order)}
                        className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600"
                      >
                        Return/Replace
                      </button>
                    )}
                    {!canReturn && isDelivered && (
                      <p className="text-sm text-gray-500">
                        7-day return window has expired
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          <Pagination currentPage={page} totalPages={totalPages} onPageChange={setPage} />
        </>
      )}
    </div>
  );
};

export default Orders;
