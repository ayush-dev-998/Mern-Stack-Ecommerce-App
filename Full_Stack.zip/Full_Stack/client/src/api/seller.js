import api from './axios';

export const getSellerProducts = (params) => api.get('/seller/products', { params });
export const createProduct = (formData) => api.post('/seller/products', formData, {
  headers: { 'Content-Type': 'multipart/form-data' },
});
export const updateProduct = (id, formData) => api.put(`/seller/products/${id}`, formData, {
  headers: { 'Content-Type': 'multipart/form-data' },
});
export const deleteProduct = (id) => api.delete(`/seller/products/${id}`);
export const getSellerOrders = (params) => api.get('/seller/orders', { params });
export const updateOrderStatus = (id, status) => api.patch(`/seller/orders/${id}/status`, { status });
export const getSellerReturns = () => api.get('/seller/returns');
export const updateReturnStatus = (returnId, status, response) => api.patch(`/seller/returns/${returnId}/status`, { status, response });

