import api from './axios';

export const getCart = () => api.get('/cart');
export const updateCart = (cartData) => api.post('/cart', cartData);
export const removeFromCart = (productId) => api.delete(`/cart/${productId}`);
export const emptyCart = () => api.delete('/cart');

