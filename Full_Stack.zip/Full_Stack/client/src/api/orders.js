import api from './axios';

export const checkout = (checkoutData) => api.post('/checkout', checkoutData);
export const getOrders = (params) => api.get('/orders', { params });
export const cancelOrder = (orderId) => api.patch(`/orders/${orderId}/cancel`);

