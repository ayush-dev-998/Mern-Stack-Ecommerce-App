import api from './axios';

export const requestReturn = (returnData) => api.post('/returns', returnData);
export const getBuyerReturns = () => api.get('/returns');

