import api from './axios';

export const getStats = () => api.get('/admin/stats');
export const getUsers = (params) => api.get('/admin/users', { params });
export const updateUserRole = (id, role) => api.patch(`/admin/users/${id}/role`, { role });
export const deleteUser = (id) => api.delete(`/admin/users/${id}`);
export const approveSeller = (id) => api.patch(`/admin/sellers/${id}/approve`);
export const rejectSeller = (id) => api.patch(`/admin/sellers/${id}/reject`);
export const getCategories = () => api.get('/admin/categories');
export const createCategory = (categoryData) => api.post('/admin/categories', categoryData);
export const getAdminProducts = (params) => api.get('/admin/products', { params });
export const createAdminProduct = (productData) => api.post('/admin/products', productData);
export const updateAdminProduct = (id, productData) => api.put(`/admin/products/${id}`, productData);
export const deleteAdminProduct = (id) => api.delete(`/admin/products/${id}`);
export const getAdminOrders = (params) => api.get('/admin/orders', { params });

