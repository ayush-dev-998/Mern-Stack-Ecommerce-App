import { Link } from 'react-router-dom';
import { BASE_URL } from '../api/axios';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';

const ProductCard = ({ product }) => {
  const { user } = useAuth();
  const { addToCart } = useCart();
  const { addItem, removeItem, isInWishlist } = useWishlist();
  const inWishlist = isInWishlist(product._id);

  const getImageUrl = (image) => {
    if (!image) return 'https://via.placeholder.com/400';
    if (image.startsWith('/uploads')) return `${BASE_URL}${image}`;
    if (image.startsWith('http')) return image;
    return image;
  };

  const handleAddToCart = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) {
      window.location.href = '/login';
      return;
    }
    try {
      await addToCart(product._id, 1);
      alert('Product added to cart!');
    } catch (error) {
      alert(error.response?.data?.message || 'Error adding to cart');
    }
  };

  const handleWishlistToggle = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) {
      window.location.href = '/login';
      return;
    }
    try {
      if (inWishlist) {
        await removeItem(product._id);
        alert('Removed from wishlist');
      } else {
        await addItem(product._id);
        alert('Added to wishlist');
      }
    } catch (error) {
      alert(error.response?.data?.message || 'Error updating wishlist');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow relative">
      <Link to={`/product/${product._id}`}>
      <div className="aspect-square overflow-hidden">
        <img
          src={getImageUrl(product.images?.[0])}
          alt={product.title}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-2 line-clamp-2">{product.title}</h3>
        <p className="text-gray-600 text-sm mb-2 line-clamp-2">{product.description}</p>
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-blue-600">${product.price}</span>
          {product.ratingAvg > 0 && (
            <div className="flex items-center">
              <span className="text-yellow-500">★</span>
              <span className="ml-1 text-sm">{product.ratingAvg.toFixed(1)}</span>
            </div>
          )}
        </div>
        {product.inventoryCount < 10 && product.inventoryCount > 0 && (
          <p className="text-orange-500 text-xs mt-2">Only {product.inventoryCount} left!</p>
        )}
        {product.inventoryCount === 0 && (
          <p className="text-red-500 text-xs mt-2">Out of stock</p>
        )}
      </div>
      </Link>
      {user && user.role === 'buyer' && product.inventoryCount > 0 && (
        <div className="absolute top-2 right-2 flex flex-col space-y-2">
          <button
            onClick={handleWishlistToggle}
            className={`p-2 rounded-full shadow-lg ${
              inWishlist ? 'bg-red-500 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
            title={inWishlist ? 'Remove from wishlist' : 'Add to wishlist'}
          >
            {inWishlist ? '❤️' : '🤍'}
          </button>
          <button
            onClick={handleAddToCart}
            className="p-2 bg-blue-500 text-white rounded-full shadow-lg hover:bg-blue-600"
            title="Add to cart"
          >
            🛒
          </button>
        </div>
      )}
    </div>
  );
};

export default ProductCard;

