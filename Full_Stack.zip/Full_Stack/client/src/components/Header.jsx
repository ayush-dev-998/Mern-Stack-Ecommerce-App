import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import NotificationBell from './NotificationBell';

const Header = () => {
  const { user, logout } = useAuth();
  const { getCartItemCount } = useCart();
  const { getWishlistCount } = useWishlist();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-2xl font-bold text-blue-600">
            E-Commerce
          </Link>

          <div className="flex items-center space-x-6">
            <Link to="/categories" className="text-gray-700 hover:text-blue-600">
              Categories
            </Link>

            {user ? (
              <>
                {user.role === 'buyer' && (
                  <>
                    <Link to="/wishlist" className="relative text-gray-700 hover:text-blue-600">
                      Wishlist
                      {getWishlistCount() > 0 && (
                        <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                          {getWishlistCount()}
                        </span>
                      )}
                    </Link>
                    <Link to="/cart" className="relative text-gray-700 hover:text-blue-600">
                      Cart
                      {getCartItemCount() > 0 && (
                        <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                          {getCartItemCount()}
                        </span>
                      )}
                    </Link>
                  </>
                )}

                {user.role === 'seller' && (
                  <Link to="/seller/dashboard" className="text-gray-700 hover:text-blue-600">
                    Seller Dashboard
                  </Link>
                )}

                {user.role === 'admin' && (
                  <Link to="/admin/dashboard" className="text-gray-700 hover:text-blue-600">
                    Admin Dashboard
                  </Link>
                )}

                {user.role === 'buyer' && (
                  <Link to="/orders" className="text-gray-700 hover:text-blue-600">
                    Orders
                  </Link>
                )}

                <Link to="/profile" className="text-gray-700 hover:text-blue-600">
                  Profile
                </Link>

                <NotificationBell />

                <div className="flex items-center space-x-2">
                  <span className="text-gray-700">{user.name}</span>
                  <button
                    onClick={handleLogout}
                    className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
                  >
                    Logout
                  </button>
                </div>
              </>
            ) : (
              <>
                <Link to="/login" className="text-gray-700 hover:text-blue-600">
                  Login
                </Link>
                <Link
                  to="/register"
                  className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                  Register
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;

