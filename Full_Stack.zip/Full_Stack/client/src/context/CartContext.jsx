import { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { getCart, updateCart, removeFromCart } from '../api/cart';

const CartContext = createContext();

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within CartProvider');
  }
  return context;
};

const CART_STORAGE_KEY = 'guest_cart';

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState({ items: [] });
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  // Load cart on mount and when user changes
  useEffect(() => {
    if (user) {
      fetchCart();
    } else {
      loadGuestCart();
    }
  }, [user]);

  const loadGuestCart = () => {
    const guestCart = localStorage.getItem(CART_STORAGE_KEY);
    if (guestCart) {
      try {
        setCart(JSON.parse(guestCart));
      } catch (error) {
        console.error('Error loading guest cart:', error);
      }
    }
  };

  const saveGuestCart = (cartData) => {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cartData));
  };

  const fetchCart = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const response = await getCart();
      setCart(response.data);
    } catch (error) {
      console.error('Error fetching cart:', error);
    } finally {
      setLoading(false);
    }
  };

  const addToCart = async (productId, quantity = 1) => {
    if (user) {
      // Logged in user
      setLoading(true);
      try {
        await updateCart({ productId, quantity });
        await fetchCart();
      } catch (error) {
        console.error('Error adding to cart:', error);
        throw error;
      } finally {
        setLoading(false);
      }
    } else {
      // Guest user - use localStorage
      const guestCart = JSON.parse(localStorage.getItem(CART_STORAGE_KEY) || '{"items":[]}');
      const existingItem = guestCart.items.find(item => item.productId === productId);
      
      if (existingItem) {
        existingItem.quantity += quantity;
      } else {
        guestCart.items.push({ productId, quantity, priceAtAdd: 0 });
      }
      
      setCart(guestCart);
      saveGuestCart(guestCart);
    }
  };

  const updateCartItem = async (productId, quantity) => {
    // Handle both string ID and object ID
    const id = typeof productId === 'string' ? productId : productId._id || productId;
    
    if (user) {
      setLoading(true);
      try {
        await updateCart({ productId: id, quantity });
        await fetchCart();
      } catch (error) {
        console.error('Error updating cart:', error);
        throw error;
      } finally {
        setLoading(false);
      }
    } else {
      const guestCart = JSON.parse(localStorage.getItem(CART_STORAGE_KEY) || '{"items":[]}');
      const item = guestCart.items.find(item => {
        const itemId = typeof item.productId === 'string' ? item.productId : item.productId._id || item.productId;
        return itemId === id;
      });
      if (item) {
        item.quantity = quantity;
        setCart(guestCart);
        saveGuestCart(guestCart);
      }
    }
  };

  const removeItem = async (productId) => {
    // Handle both string ID and object ID
    const id = typeof productId === 'string' ? productId : productId._id || productId;
    
    if (user) {
      setLoading(true);
      try {
        await removeFromCart(id);
        await fetchCart();
      } catch (error) {
        console.error('Error removing from cart:', error);
        throw error;
      } finally {
        setLoading(false);
      }
    } else {
      const guestCart = JSON.parse(localStorage.getItem(CART_STORAGE_KEY) || '{"items":[]}');
      guestCart.items = guestCart.items.filter(item => {
        const itemId = typeof item.productId === 'string' ? item.productId : item.productId._id || item.productId;
        return itemId !== id;
      });
      setCart(guestCart);
      saveGuestCart(guestCart);
    }
  };

  const syncGuestCart = async () => {
    if (!user) return;
    
    const guestCart = JSON.parse(localStorage.getItem(CART_STORAGE_KEY) || '{"items":[]}');
    if (guestCart.items.length > 0) {
      try {
        for (const item of guestCart.items) {
          await updateCart({ productId: item.productId, quantity: item.quantity });
        }
        localStorage.removeItem(CART_STORAGE_KEY);
        await fetchCart();
      } catch (error) {
        console.error('Error syncing guest cart:', error);
      }
    }
  };

  const getCartItemCount = () => {
    if (!cart.items) return 0;
    return cart.items.reduce((total, item) => total + (item.quantity || 0), 0);
  };

  const getCartTotal = () => {
    if (!cart.items) return 0;
    return cart.items.reduce((total, item) => {
      // Handle both populated productId (object) and string ID
      const price = (item.productId && typeof item.productId === 'object' && item.productId.price)
        ? item.productId.price
        : item.priceAtAdd || 0;
      return total + (price * (item.quantity || 0));
    }, 0);
  };

  const getDeliveryFee = () => {
    const subtotal = getCartTotal();
    // Dummy delivery fee: $5 for orders under $100, free for $100+
    return subtotal >= 100 ? 0 : 5;
  };

  const getGrandTotal = () => {
    return getCartTotal() + getDeliveryFee();
  };

  const emptyCart = async () => {
    if (user) {
      setLoading(true);
      try {
        const { emptyCart: emptyCartAPI } = await import('../api/cart');
        await emptyCartAPI();
        await fetchCart();
      } catch (error) {
        console.error('Error emptying cart:', error);
        throw error;
      } finally {
        setLoading(false);
      }
    } else {
      setCart({ items: [] });
      localStorage.removeItem(CART_STORAGE_KEY);
    }
  };

  const value = {
    cart,
    loading,
    addToCart,
    updateCartItem,
    removeItem,
    fetchCart,
    syncGuestCart,
    getCartItemCount,
    getCartTotal,
    getDeliveryFee,
    getGrandTotal,
    emptyCart,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};

