import { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { getWishlist, addToWishlist, removeFromWishlist, emptyWishlist } from '../api/wishlist';

const WishlistContext = createContext();

export const useWishlist = () => {
  const context = useContext(WishlistContext);
  if (!context) {
    throw new Error('useWishlist must be used within WishlistProvider');
  }
  return context;
};

export const WishlistProvider = ({ children }) => {
  const [wishlist, setWishlist] = useState({ items: [] });
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    if (user && user.role === 'buyer') {
      fetchWishlist();
    } else {
      setWishlist({ items: [] });
    }
  }, [user]);

  const fetchWishlist = async () => {
    if (!user || user.role !== 'buyer') return;
    setLoading(true);
    try {
      const response = await getWishlist();
      setWishlist(response.data);
    } catch (error) {
      console.error('Error fetching wishlist:', error);
    } finally {
      setLoading(false);
    }
  };

  const addItem = async (productId) => {
    if (!user || user.role !== 'buyer') {
      throw new Error('You must be logged in as a buyer to add to wishlist');
    }
    setLoading(true);
    try {
      await addToWishlist(productId);
      await fetchWishlist();
    } catch (error) {
      console.error('Error adding to wishlist:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const removeItem = async (productId) => {
    if (!user || user.role !== 'buyer') return;
    setLoading(true);
    try {
      await removeFromWishlist(productId);
      await fetchWishlist();
    } catch (error) {
      console.error('Error removing from wishlist:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const emptyWishlistItems = async () => {
    if (!user || user.role !== 'buyer') return;
    setLoading(true);
    try {
      await emptyWishlist();
      await fetchWishlist();
    } catch (error) {
      console.error('Error emptying wishlist:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const isInWishlist = (productId) => {
    if (!wishlist.items) return false;
    return wishlist.items.some(item => {
      const id = typeof item.productId === 'string' 
        ? item.productId 
        : item.productId._id || item.productId;
      return id === productId;
    });
  };

  const getWishlistCount = () => {
    if (!wishlist.items) return 0;
    return wishlist.items.length;
  };

  const value = {
    wishlist,
    loading,
    addItem,
    removeItem,
    emptyWishlistItems,
    fetchWishlist,
    isInWishlist,
    getWishlistCount,
  };

  return <WishlistContext.Provider value={value}>{children}</WishlistContext.Provider>;
};

