import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

// Ensure .env loads before transporter is created
dotenv.config();

// Read env AFTER .env is loaded
const emailUser = process.env.EMAIL_USER || 'ecommercenoreply2025@gmail.com';
const emailPassword = process.env.EMAIL_PASSWORD || '';

let transporter = null;

// Create transporter lazily so that env variables are definitely available
function getTransporter() {
  if (transporter) return transporter;
  if (!emailPassword) {
    console.warn('⚠ EMAIL_PASSWORD missing — emails will log to console.');
    return null;
  }

  transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: emailUser,
      pass: emailPassword,
    },
  });

  return transporter;
}

// ---------------------
// Send email function
// ---------------------
export const sendEmail = async (to, subject, html) => {
  const transporterInstance = getTransporter();

  // Fallback if transporter not configured
  if (!transporterInstance) {
    console.log('='.repeat(50));
    console.log('📧 EMAIL (Credentials not configured - logging to console)');
    console.log('To:', to);
    console.log('Subject:', subject);
    console.log('Body:', html);
    console.log('='.repeat(50));
    return { success: true, messageId: 'console-log' };
  }

  try {
    const mailOptions = {
      from: emailUser,
      to,
      subject,
      html,
    };

    const info = await transporterInstance.sendMail(mailOptions);
    console.log('✅ Email sent successfully:', info.messageId);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ Error sending email:', error.message);

    // Fallback log
    console.log('='.repeat(50));
    console.log('📧 EMAIL (Fallback - email sending failed)');
    console.log('To:', to);
    console.log('Subject:', subject);
    console.log('Body:', html);
    console.log('='.repeat(50));

    return { success: false, error: error.message };
  }
};

// ---------------------
// All your original functions
// (UNCHANGED)
// ---------------------

export const sendOrderPlacedEmail = async (userEmail, orderDetails) => {
  const subject = 'Order Placed Successfully';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #2563eb;">Order Confirmation</h2>
      <p>Dear Customer,</p>
      <p>Your order has been placed successfully!</p>
      <div style="background-color: #f3f4f6; padding: 15px; border-radius: 5px; margin: 20px 0;">
        <p><strong>Order ID:</strong> ${orderDetails._id.toString().slice(-8)}</p>
        <p><strong>Total Amount:</strong> $${orderDetails.totalAmount.toFixed(2)}</p>
        <p><strong>Payment Method:</strong> ${orderDetails.paymentMethod}</p>
        <p><strong>Status:</strong> ${orderDetails.status}</p>
      </div>
      <p>Thank you for shopping with us!</p>
      <p>Best regards,<br>E-Commerce Team</p>
    </div>
  `;
  return await sendEmail(userEmail, subject, html);
};

export const sendOrderCancelledEmail = async (userEmail, orderDetails) => {
  const subject = 'Order Cancelled';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #dc2626;">Order Cancellation Confirmation</h2>
      <p>Dear Customer,</p>
      <p>Your order has been cancelled.</p>
      <div style="background-color: #f3f4f6; padding: 15px; border-radius: 5px; margin: 20px 0;">
        <p><strong>Order ID:</strong> ${orderDetails._id.toString().slice(-8)}</p>
        <p><strong>Total Amount:</strong> $${orderDetails.totalAmount.toFixed(2)}</p>
      </div>
      <p>The amount (if paid) will be refunded to your account within 5-7 business days.</p>
      <p>Thank you!</p>
      <p>Best regards,<br>E-Commerce Team</p>
    </div>
  `;
  return await sendEmail(userEmail, subject, html);
};

export const sendPaymentSuccessEmail = async (userEmail, orderDetails) => {
  const subject = 'Payment Successful';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #16a34a;">Payment Confirmation</h2>
      <p>Dear Customer,</p>
      <p>Your payment has been processed successfully!</p>
      <div style="background-color: #f3f4f6; padding: 15px; border-radius: 5px; margin: 20px 0;">
        <p><strong>Order ID:</strong> ${orderDetails._id.toString().slice(-8)}</p>
        <p><strong>Amount Paid:</strong> $${orderDetails.totalAmount.toFixed(2)}</p>
        <p><strong>Payment Method:</strong> ${orderDetails.paymentMethod}</p>
      </div>
      <p>Your order will be processed and shipped soon.</p>
      <p>Thank you!</p>
      <p>Best regards,<br>E-Commerce Team</p>
    </div>
  `;
  return await sendEmail(userEmail, subject, html);
};

export const sendOrderDeliveredEmail = async (userEmail, orderDetails) => {
  const subject = 'Order Delivered';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #16a34a;">Order Delivered</h2>
      <p>Dear Customer,</p>
      <p>Your order has been delivered successfully!</p>
      <div style="background-color: #f3f4f6; padding: 15px; border-radius: 5px; margin: 20px 0;">
        <p><strong>Order ID:</strong> ${orderDetails._id.toString().slice(-8)}</p>
      </div>
      <p>We hope you enjoy your purchase. If you need to return or replace any item, please do so within 7 days of delivery.</p>
      <p>Thank you for shopping with us!</p>
      <p>Best regards,<br>E-Commerce Team</p>
    </div>
  `;
  return await sendEmail(userEmail, subject, html);
};

export const sendSellerApprovalEmail = async (sellerEmail, sellerName) => {
  const subject = 'Seller Account Approved';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #16a34a;">Account Approval</h2>
      <p>Dear ${sellerName},</p>
      <p>Congratulations! Your seller account has been approved.</p>
      <p>You can now start adding products and managing your store.</p>
      <p>Thank you for joining us!</p>
      <p>Best regards,<br>E-Commerce Team</p>
    </div>
  `;
  return await sendEmail(sellerEmail, subject, html);
};

export const sendSellerRejectionEmail = async (sellerEmail, sellerName) => {
  const subject = 'Seller Account Rejected';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #dc2626;">Account Status Update</h2>
      <p>Dear ${sellerName},</p>
      <p>We regret to inform you that your seller account application has been rejected.</p>
      <p>If you have any questions, please contact our support team.</p>
      <p>Thank you for your interest.</p>
      <p>Best regards,<br>E-Commerce Team</p>
    </div>
  `;
  return await sendEmail(sellerEmail, subject, html);
};

export const sendOTPEmail = async (userEmail, otp) => {
  const subject = 'Password Reset OTP';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #2563eb;">Password Reset Request</h2>
      <p>Dear User,</p>
      <p>You have requested to reset your password. Please use the following OTP to verify your identity:</p>
      <div style="background-color: #f3f4f6; padding: 20px; border-radius: 5px; margin: 20px 0; text-align: center;">
        <h1 style="color: #2563eb; font-size: 32px; letter-spacing: 5px; margin: 0;">${otp}</h1>
      </div>
      <p>This OTP will expire in 10 minutes. If you did not request this, please ignore this email.</p>
      <p>Best regards,<br>E-Commerce Team</p>
    </div>
  `;
  return await sendEmail(userEmail, subject, html);
};

export const sendPasswordChangedEmail = async (userEmail, userName) => {
  const subject = 'Password Changed Successfully';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #16a34a;">Password Changed</h2>
      <p>Dear ${userName},</p>
      <p>Your password has been successfully changed.</p>
      <p>If you did not make this change, please contact our support team immediately.</p>
      <p>Best regards,<br>E-Commerce Team</p>
    </div>
  `;
  return await sendEmail(userEmail, subject, html);
};
