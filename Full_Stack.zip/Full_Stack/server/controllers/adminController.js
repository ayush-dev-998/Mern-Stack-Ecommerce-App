import User from '../models/User.js';
import Product from '../models/Product.js';
import Category from '../models/Category.js';
import Order from '../models/Order.js';
import { sendSellerApprovalEmail, sendSellerRejectionEmail } from '../utils/emailService.js';

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private (Admin)
export const getUsers = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    const role = req.query.role; // Optional filter by role

    // Handle users that may not have isDeleted field
    const query = {
      $or: [{ isDeleted: { $exists: false } }, { isDeleted: false }]
    };
    if (role) {
      query.role = role;
    }

    const users = await User.find(query)
      .select('-passwordHash')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    const total = await User.countDocuments(query);

    res.json({
      users,
      page,
      pages: Math.ceil(total / limit),
      total,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update user role
// @route   PATCH /api/admin/users/:id/role
// @access  Private (Admin)
export const updateUserRole = async (req, res) => {
  try {
    const { role } = req.body;

    if (!role || !['buyer', 'seller', 'admin'].includes(role)) {
      return res.status(400).json({ message: 'Please provide a valid role' });
    }

    const user = await User.findById(req.params.id);

    if (!user || user.isDeleted) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.role = role;
    await user.save();

    const updatedUser = await User.findById(user._id).select('-passwordHash');

    res.json(updatedUser);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete user
// @route   DELETE /api/admin/users/:id
// @access  Private (Admin)
export const deleteUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Mark as deleted instead of actually deleting (allows re-registration)
    user.isDeleted = true;
    await user.save();

    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Approve seller
// @route   PATCH /api/admin/sellers/:id/approve
// @access  Private (Admin)
export const approveSeller = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user || user.role !== 'seller') {
      return res.status(404).json({ message: 'Seller not found' });
    }

    user.approvalStatus = 'approved';
    await user.save();

    // Optionally send notification/email here if desired
    if (user.email) {
      try {
        await sendSellerApprovalEmail(user.email, user.name);
      } catch (emailErr) {
        console.error('Error sending approval email:', emailErr);
      }
    }

    const updatedUser = await User.findById(user._id).select('-passwordHash');
    res.json(updatedUser);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Reject seller
// @route   PATCH /api/admin/sellers/:id/reject
// @access  Private (Admin)
export const rejectSeller = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user || user.role !== 'seller') {
      return res.status(404).json({ message: 'Seller not found' });
    }

    user.approvalStatus = 'rejected';
    await user.save();

    // Dynamically import createNotification to avoid circular import / duplicate identifier issues
    try {
      const module = await import('./notificationController.js');
      const createNotification = module.createNotification ?? module.default ?? null;

      if (typeof createNotification === 'function') {
        await createNotification(
          user._id,
          'seller_rejected',
          'Account Rejected',
          'Your seller account application has been rejected.',
          user._id,
          'User'
        );
      } else {
        console.warn('createNotification not available or not a function');
      }
    } catch (impErr) {
      // Log but don't break the flow if notifications fail to import/run
      console.error('Failed to import or run createNotification:', impErr);
    }

    // Send email
    if (user.email) {
      try {
        await sendSellerRejectionEmail(user.email, user.name);
      } catch (emailErr) {
        console.error('Error sending rejection email:', emailErr);
      }
    }

    const updatedUser = await User.findById(user._id).select('-passwordHash');
    res.json(updatedUser);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get dashboard stats
// @route   GET /api/admin/stats
// @access  Private (Admin)
export const getStats = async (req, res) => {
  try {
    // Count users - check if isDeleted field exists, if not count all
    const totalUsers = await User.countDocuments({ 
      $or: [{ isDeleted: { $exists: false } }, { isDeleted: false }] 
    });
    const totalProducts = await Product.countDocuments();
    const totalOrders = await Order.countDocuments();
    const totalBuyers = await User.countDocuments({ 
      role: 'buyer',
      $or: [{ isDeleted: { $exists: false } }, { isDeleted: false }]
    });
    const totalSellers = await User.countDocuments({ 
      role: 'seller',
      $or: [{ isDeleted: { $exists: false } }, { isDeleted: false }]
    });
    const pendingSellers = await User.countDocuments({ 
      role: 'seller',
      approvalStatus: 'pending',
      $or: [{ isDeleted: { $exists: false } }, { isDeleted: false }]
    });

    // Count return/replace requests
    const Return = (await import('../models/Return.js')).default;
    const totalReturns = await Return.countDocuments();
    const pendingReturns = await Return.countDocuments({ status: 'pending' });
    const approvedReturns = await Return.countDocuments({ status: 'approved' });
    const completedReturns = await Return.countDocuments({ status: 'completed' });

    res.json({
      totalUsers,
      totalProducts,
      totalOrders,
      totalBuyers,
      totalSellers,
      pendingSellers,
      totalReturns,
      pendingReturns,
      approvedReturns,
      completedReturns,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all categories
// @route   GET /api/admin/categories
// @access  Private (Admin)
export const getCategories = async (req, res) => {
  try {
    const categories = await Category.find().sort({ name: 1 });
    res.json(categories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Create category
// @route   POST /api/admin/categories
// @access  Private (Admin)
export const createCategory = async (req, res) => {
  try {
    const { name } = req.body;

    if (!name) {
      return res.status(400).json({ message: 'Please provide a category name' });
    }

    const slug = name.toLowerCase().replace(/\s+/g, '-');

    const category = await Category.create({ name, slug });

    res.status(201).json(category);
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ message: 'Category already exists' });
    }
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all products
// @route   GET /api/admin/products
// @access  Private (Admin)
export const getAdminProducts = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const products = await Product.find()
      .populate('categoryId', 'name slug')
      .populate('sellerId', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    const total = await Product.countDocuments();

    res.json({
      products,
      page,
      pages: Math.ceil(total / limit),
      total,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Create product (Admin)
// @route   POST /api/admin/products
// @access  Private (Admin)
export const createAdminProduct = async (req, res) => {
  try {
    const { title, description, price, images, inventoryCount, categoryId, sellerId } = req.body;

    if (!title || !description || !price || !categoryId || !sellerId) {
      return res.status(400).json({ message: 'Please provide all required fields' });
    }

    // Validate price and inventoryCount are not negative
    const priceNum = parseFloat(price);
    const inventoryNum = parseInt(inventoryCount) || 0;

    if (priceNum < 0) {
      return res.status(400).json({ message: 'Price cannot be negative' });
    }

    if (inventoryNum < 0) {
      return res.status(400).json({ message: 'Inventory count cannot be negative' });
    }

    const product = await Product.create({
      title,
      description,
      price: priceNum,
      images: images || [],
      inventoryCount: inventoryNum,
      categoryId,
      sellerId,
    });

    const createdProduct = await Product.findById(product._id)
      .populate('categoryId', 'name slug')
      .populate('sellerId', 'name email');

    res.status(201).json(createdProduct);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update product (Admin)
// @route   PUT /api/admin/products/:id
// @access  Private (Admin)
export const updateAdminProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    const { title, description, price, images, inventoryCount, categoryId, sellerId } = req.body;

    if (title) product.title = title;
    if (description) product.description = description;
    if (price !== undefined) {
      const priceNum = parseFloat(price);
      if (priceNum < 0) {
        return res.status(400).json({ message: 'Price cannot be negative' });
      }
      product.price = priceNum;
    }
    if (images) product.images = images;
    if (inventoryCount !== undefined) {
      const inventoryNum = parseInt(inventoryCount);
      if (inventoryNum < 0) {
        return res.status(400).json({ message: 'Inventory count cannot be negative' });
      }
      product.inventoryCount = inventoryNum;
    }
    if (categoryId) product.categoryId = categoryId;
    if (sellerId) product.sellerId = sellerId;

    await product.save();

    const updatedProduct = await Product.findById(product._id)
      .populate('categoryId', 'name slug')
      .populate('sellerId', 'name email');

    res.json(updatedProduct);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete product (Admin)
// @route   DELETE /api/admin/products/:id
// @access  Private (Admin)
export const deleteAdminProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    await Product.findByIdAndDelete(req.params.id);

    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all orders
// @route   GET /api/admin/orders
// @access  Private (Admin)
export const getAdminOrders = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const orders = await Order.find()
      .populate('items.productId', 'title images')
      .populate('userId', 'name email')
      .populate('sellerId', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    const total = await Order.countDocuments();

    res.json({
      orders,
      page,
      pages: Math.ceil(total / limit),
      total,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
