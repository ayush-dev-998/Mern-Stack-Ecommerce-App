import Product from '../models/Product.js';
import Review from '../models/Review.js';

// @desc    Get all products with filters, search, sort, pagination
// @route   GET /api/products
// @access  Public
export const getProducts = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 12;
    const skip = (page - 1) * limit;

    // Build query
    const query = {};

    // Search
    if (req.query.search) {
      query.$or = [
        { title: { $regex: req.query.search, $options: 'i' } },
        { description: { $regex: req.query.search, $options: 'i' } },
      ];
    }

    // Category filter
    if (req.query.category) {
      query.categoryId = req.query.category;
    }

    // Price range
    if (req.query.minPrice) {
      query.price = { ...query.price, $gte: parseFloat(req.query.minPrice) };
    }
    if (req.query.maxPrice) {
      query.price = { ...query.price, $lte: parseFloat(req.query.maxPrice) };
    }

    // Sort
    let sortBy = {};
    if (req.query.sort) {
      switch (req.query.sort) {
        case 'price_asc':
          sortBy = { price: 1 };
          break;
        case 'price_desc':
          sortBy = { price: -1 };
          break;
        case 'rating':
          sortBy = { ratingAvg: -1 };
          break;
        case 'newest':
          sortBy = { createdAt: -1 };
          break;
        default:
          sortBy = { createdAt: -1 };
      }
    } else {
      sortBy = { createdAt: -1 };
    }

    const products = await Product.find(query)
      .populate('categoryId', 'name slug')
      .populate('sellerId', 'name email')
      .sort(sortBy)
      .skip(skip)
      .limit(limit);

    const total = await Product.countDocuments(query);

    res.json({
      products,
      page,
      pages: Math.ceil(total / limit),
      total,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get single product
// @route   GET /api/products/:id
// @access  Public
export const getProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id)
      .populate('categoryId', 'name slug')
      .populate('sellerId', 'name email sellerProfile');

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Get reviews
    const reviews = await Review.find({ productId: req.params.id })
      .populate('userId', 'name')
      .sort({ createdAt: -1 });

    res.json({ product, reviews });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Add review to product
// @route   POST /api/products/:id/review
// @access  Private (Buyer)
export const addReview = async (req, res) => {
  try {
    const { rating, comment } = req.body;

    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({ message: 'Please provide a valid rating (1-5)' });
    }

    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Check if review already exists - enforce one review per user per product
    const existingReview = await Review.findOne({
      userId: req.user._id,
      productId: req.params.id,
    });

    if (existingReview) {
      // Update existing review (user can edit their review)
      existingReview.rating = rating;
      existingReview.comment = comment || existingReview.comment;
      existingReview.updatedAt = new Date();
      await existingReview.save();
    } else {
      // Create new review (only one per user per product allowed)
      try {
        await Review.create({
          userId: req.user._id,
          productId: req.params.id,
          rating,
          comment,
        });
      } catch (error) {
        // Handle unique constraint violation
        if (error.code === 11000) {
          return res.status(400).json({ 
            message: 'You have already reviewed this product. You can edit your existing review.' 
          });
        }
        throw error;
      }
    }

    // Recalculate average rating
    const reviews = await Review.find({ productId: req.params.id });
    if (reviews.length > 0) {
      const avgRating = reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;
      product.ratingAvg = Math.round(avgRating * 10) / 10;
    } else {
      product.ratingAvg = 0;
    }
    await product.save();

    const updatedReview = existingReview || await Review.findOne({
      userId: req.user._id,
      productId: req.params.id,
    }).populate('userId', 'name');

    res.status(201).json({ 
      message: existingReview ? 'Review updated successfully' : 'Review added successfully',
      review: updatedReview
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

