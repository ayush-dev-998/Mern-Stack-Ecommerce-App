import Order from '../models/Order.js';
import Cart from '../models/Cart.js';
import Product from '../models/Product.js';
import { createNotification } from './notificationController.js';
import { sendOrderPlacedEmail, sendPaymentSuccessEmail, sendOrderCancelledEmail } from '../utils/emailService.js';
import User from '../models/User.js';

// @desc    Create order from cart
// @route   POST /api/checkout
// @access  Private (Buyer)
export const checkout = async (req, res) => {
  try {
    const { shippingAddress, paymentMethod, paymentDetails } = req.body;

    if (!shippingAddress || !paymentMethod) {
      return res.status(400).json({ message: 'Please provide shipping address and payment method' });
    }

    if (!['cash', 'card', 'upi'].includes(paymentMethod)) {
      return res.status(400).json({ message: 'Invalid payment method. Must be cash, card, or upi' });
    }

    const cart = await Cart.findOne({ userId: req.user._id }).populate('items.productId');

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: 'Cart is empty' });
    }

    // Validate inventory and calculate totals
    let totalAmount = 0;
    const orderItems = [];

    for (const item of cart.items) {
      const product = await Product.findById(item.productId._id);
      
      if (!product) {
        return res.status(404).json({ message: `Product ${item.productId._id} not found` });
      }

      if (product.inventoryCount < item.quantity) {
        return res.status(400).json({ 
          message: `Insufficient inventory for ${product.title}` 
        });
      }

      const itemTotal = item.priceAtAdd * item.quantity;
      totalAmount += itemTotal;

      orderItems.push({
        productId: item.productId._id,
        quantity: item.quantity,
        unitPrice: item.priceAtAdd,
      });

      // Update inventory - reduce stock
      product.inventoryCount -= item.quantity;
      await product.save();
    }

    // Add delivery fee (dummy: $5 for orders under $100, free for $100+)
    const deliveryFee = totalAmount >= 100 ? 0 : 5;
    totalAmount += deliveryFee;

    // Mock payment validation
    let paymentStatus = 'paid';
    if (paymentMethod === 'card') {
      // Card starting with "4" is successful
      if (!paymentDetails || !paymentDetails.startsWith('4')) {
        paymentStatus = 'failed';
      }
    } else if (paymentMethod === 'upi') {
      // UPI ID format validation (simple check)
      if (!paymentDetails || !paymentDetails.includes('@')) {
        paymentStatus = 'failed';
      }
    } else if (paymentMethod === 'cash') {
      // Cash on delivery - always pending until delivery
      paymentStatus = 'pending';
    }

    if (paymentStatus === 'failed') {
      // Restore inventory if payment failed
      for (const item of orderItems) {
        const product = await Product.findById(item.productId);
        if (product) {
          product.inventoryCount += item.quantity;
          await product.save();
        }
      }
      return res.status(400).json({ 
        message: paymentMethod === 'card' 
          ? 'Payment failed. Use a card number starting with 4 for successful payment.' 
          : paymentMethod === 'upi'
          ? 'Payment failed. Please enter a valid UPI ID (e.g., name@paytm).'
          : 'Payment failed. Please check your payment details.'
      });
    }

    // Create order (assuming single seller per order for simplicity)
    // In real app, you might split by seller
    const sellerId = cart.items[0].productId.sellerId;

    const order = await Order.create({
      userId: req.user._id,
      sellerId,
      items: orderItems,
      shippingAddress,
      paymentMethod,
      paymentStatus,
      status: 'Placed',
      totalAmount,
    });

    // Clear cart
    cart.items = [];
    await cart.save();

    const createdOrder = await Order.findById(order._id)
      .populate('items.productId', 'title images')
      .populate('sellerId', 'name email');

    // Create notification
    await createNotification(
      req.user._id,
      `Your order #${order._id.toString().slice(-8)} has been placed successfully!`,
      '/orders',
      'order_placed'
    );

    // Send email
    const user = await User.findById(req.user._id);
    if (user && user.email) {
      await sendOrderPlacedEmail(user.email, createdOrder);
      if (paymentStatus === 'paid') {
        await sendPaymentSuccessEmail(user.email, createdOrder);
      }
    }

    res.status(201).json(createdOrder);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get user orders
// @route   GET /api/orders
// @access  Private (Buyer)
export const getOrders = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const orders = await Order.find({ userId: req.user._id })
      .populate('items.productId', 'title images')
      .populate('sellerId', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    const total = await Order.countDocuments({ userId: req.user._id });

    res.json({
      orders,
      page,
      pages: Math.ceil(total / limit),
      total,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Cancel order
// @route   PATCH /api/orders/:id/cancel
// @access  Private (Buyer)
export const cancelOrder = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    // Check if order belongs to user
    if (order.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to cancel this order' });
    }

    // Check if order can be cancelled (only Placed orders can be cancelled)
    if (order.status !== 'Placed') {
      return res.status(400).json({ 
        message: `Cannot cancel order. Order status is ${order.status}. Only Placed orders can be cancelled.` 
      });
    }

    // Restore inventory
    for (const item of order.items) {
      const product = await Product.findById(item.productId);
      if (product) {
        product.inventoryCount += item.quantity;
        await product.save();
      }
    }

    // Update order status
    order.status = 'Cancelled';
    await order.save();

    const updatedOrder = await Order.findById(order._id)
      .populate('items.productId', 'title images')
      .populate('sellerId', 'name email');

    // Create notification
    await createNotification(
      req.user._id,
      `Your order #${order._id.toString().slice(-8)} has been cancelled. Stock has been restored.`,
      '/orders',
      'order_cancelled'
    );

    // Send email
    const user = await User.findById(req.user._id);
    if (user && user.email) {
      await sendOrderCancelledEmail(user.email, updatedOrder);
    }

    res.json({ message: 'Order cancelled successfully', order: updatedOrder });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
