import Product from '../models/Product.js';
import Order from '../models/Order.js';
import User from '../models/User.js';
import { createNotification } from './notificationController.js';
import { sendOrderDeliveredEmail } from '../utils/emailService.js';

// @desc    Get seller products
// @route   GET /api/seller/products
// @access  Private (Seller)
export const getSellerProducts = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const products = await Product.find({ sellerId: req.user._id })
      .populate('categoryId', 'name slug')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    const total = await Product.countDocuments({ sellerId: req.user._id });

    res.json({
      products,
      page,
      pages: Math.ceil(total / limit),
      total,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Create product
// @route   POST /api/seller/products
// @access  Private (Seller)
export const createProduct = async (req, res) => {
  try {
    // Check if seller is approved
    if (req.user.role === 'seller' && req.user.approvalStatus !== 'approved') {
      return res.status(403).json({ 
        message: 'Your seller account is pending admin approval. You cannot add products until approved.' 
      });
    }

    const { title, description, price, inventoryCount, categoryId } = req.body;

    if (!title || !description || !price || !categoryId) {
      return res.status(400).json({ message: 'Please provide all required fields' });
    }

    // Validate price and inventoryCount are not negative
    const priceNum = parseFloat(price);
    const inventoryNum = parseInt(inventoryCount) || 0;

    if (priceNum < 0) {
      return res.status(400).json({ message: 'Price cannot be negative' });
    }

    if (inventoryNum < 0) {
      return res.status(400).json({ message: 'Inventory count cannot be negative' });
    }

    // Handle uploaded images
    const images = req.files
      ? req.files.map((file) => `/uploads/${file.filename}`)
      : [];

    const product = await Product.create({
      title,
      description,
      price: priceNum,
      images: images,
      inventoryCount: inventoryNum,
      categoryId,
      sellerId: req.user._id,
    });

    const createdProduct = await Product.findById(product._id)
      .populate('categoryId', 'name slug');

    res.status(201).json(createdProduct);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update product
// @route   PUT /api/seller/products/:id
// @access  Private (Seller)
export const updateProduct = async (req, res) => {
  try {
    // Check if seller is approved
    if (req.user.role === 'seller' && req.user.approvalStatus !== 'approved') {
      return res.status(403).json({ 
        message: 'Your seller account is pending admin approval. You cannot update products until approved.' 
      });
    }

    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Check ownership
    if (product.sellerId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to update this product' });
    }

    const { title, description, price, inventoryCount, categoryId, keepExistingImages } = req.body;

    if (title) product.title = title;
    if (description) product.description = description;
    if (price !== undefined) {
      const priceNum = parseFloat(price);
      if (priceNum < 0) {
        return res.status(400).json({ message: 'Price cannot be negative' });
      }
      product.price = priceNum;
    }
    if (inventoryCount !== undefined) {
      const inventoryNum = parseInt(inventoryCount);
      if (inventoryNum < 0) {
        return res.status(400).json({ message: 'Inventory count cannot be negative' });
      }
      product.inventoryCount = inventoryNum;
    }
    if (categoryId) product.categoryId = categoryId;

    // Handle uploaded images
    if (req.files && req.files.length > 0) {
      const newImages = req.files.map((file) => `/uploads/${file.filename}`);
      if (keepExistingImages === 'true') {
        product.images = [...product.images, ...newImages];
      } else {
        product.images = newImages;
      }
    }

    await product.save();

    const updatedProduct = await Product.findById(product._id)
      .populate('categoryId', 'name slug');

    res.json(updatedProduct);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete product
// @route   DELETE /api/seller/products/:id
// @access  Private (Seller)
export const deleteProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Check ownership
    if (product.sellerId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to delete this product' });
    }

    await Product.findByIdAndDelete(req.params.id);

    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get seller orders
// @route   GET /api/seller/orders
// @access  Private (Seller)
export const getSellerOrders = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const orders = await Order.find({ sellerId: req.user._id })
      .populate('items.productId', 'title images')
      .populate('userId', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    const total = await Order.countDocuments({ sellerId: req.user._id });

    res.json({
      orders,
      page,
      pages: Math.ceil(total / limit),
      total,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update order status
// @route   PATCH /api/seller/orders/:id/status
// @access  Private (Seller)
export const updateOrderStatus = async (req, res) => {
  try {
    const { status } = req.body;

    if (!status || !['Placed', 'Shipped', 'Delivered'].includes(status)) {
      return res.status(400).json({ message: 'Please provide a valid status' });
    }

    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    // Check ownership
    if (order.sellerId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to update this order' });
    }

    order.status = status;
    await order.save();

    // Create notification for buyer
    const notificationType = status === 'Delivered' ? 'order_delivered' : 'order_placed';
    await createNotification(
      order.userId,
      `Your order #${order._id.toString().slice(-8)} status has been updated to ${status}.`,
      '/orders',
      notificationType
    );

    // Send email if delivered
    if (status === 'Delivered') {
      const buyer = await User.findById(order.userId);
      if (buyer && buyer.email) {
        await sendOrderDeliveredEmail(buyer.email, order);
      }
    }

    const updatedOrder = await Order.findById(order._id)
      .populate('items.productId', 'title images')
      .populate('userId', 'name email');

    res.json(updatedOrder);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

