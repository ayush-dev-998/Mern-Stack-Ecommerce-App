import Return from '../models/Return.js';
import Order from '../models/Order.js';
import Product from '../models/Product.js';
import { createNotification } from './notificationController.js';

// @desc    Request return/replace
// @route   POST /api/returns
// @access  Private (Buyer)
export const requestReturn = async (req, res) => {
  try {
    const { orderId, items, type } = req.body;

    if (!orderId || !items || !type) {
      return res.status(400).json({ message: 'Please provide orderId, items, and type' });
    }

    if (!['return', 'replace'].includes(type)) {
      return res.status(400).json({ message: 'Type must be return or replace' });
    }

    const order = await Order.findById(orderId);

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    // Check if order belongs to user
    if (order.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    // Check if order is delivered
    if (order.status !== 'Delivered') {
      return res.status(400).json({ message: 'Only delivered orders can be returned/replaced' });
    }

    // Check if order is within 7 days
    const deliveryDate = new Date(order.updatedAt || order.createdAt);
    const daysSinceDelivery = (Date.now() - deliveryDate.getTime()) / (1000 * 60 * 60 * 24);
    
    if (daysSinceDelivery > 7) {
      return res.status(400).json({ message: 'Return/replace request must be made within 7 days of delivery' });
    }

    // Check if return already exists
    const existingReturn = await Return.findOne({ orderId, status: { $in: ['pending', 'approved', 'processing'] } });
    if (existingReturn) {
      return res.status(400).json({ message: 'A return/replace request already exists for this order' });
    }

    const returnRequest = await Return.create({
      orderId,
      userId: req.user._id,
      sellerId: order.sellerId,
      items,
      type,
      status: 'pending',
    });

    // Create notification for seller
    await createNotification(
      order.sellerId,
      `A ${type} request has been made for order #${orderId.toString().slice(-8)}`,
      '/seller/returns',
      'return_requested'
    );

    const createdReturn = await Return.findById(returnRequest._id)
      .populate('orderId')
      .populate('items.productId', 'title images');

    res.status(201).json(createdReturn);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get buyer returns
// @route   GET /api/returns
// @access  Private (Buyer)
export const getBuyerReturns = async (req, res) => {
  try {
    const returns = await Return.find({ userId: req.user._id })
      .populate('orderId')
      .populate('items.productId', 'title images')
      .populate('sellerId', 'name email')
      .sort({ requestDate: -1 });

    res.json(returns);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get seller returns
// @route   GET /api/seller/returns
// @access  Private (Seller)
export const getSellerReturns = async (req, res) => {
  try {
    const returns = await Return.find({ sellerId: req.user._id })
      .populate('orderId')
      .populate('items.productId', 'title images')
      .populate('userId', 'name email')
      .sort({ requestDate: -1 });

    res.json(returns);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update return status (Seller)
// @route   PATCH /api/seller/returns/:id/status
// @access  Private (Seller)
export const updateReturnStatus = async (req, res) => {
  try {
    const { status, response } = req.body;

    if (!status || !['approved', 'rejected', 'processing', 'completed'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status' });
    }

    const returnRequest = await Return.findById(req.params.id);

    if (!returnRequest) {
      return res.status(404).json({ message: 'Return request not found' });
    }

    // Check if seller owns this return
    if (returnRequest.sellerId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    returnRequest.status = status;
    if (response) {
      returnRequest.sellerResponse = response;
    }
    returnRequest.updatedAt = new Date();
    await returnRequest.save();

    // Restore stock if approved
    if (status === 'approved') {
      for (const item of returnRequest.items) {
        const product = await Product.findById(item.productId);
        if (product) {
          product.inventoryCount += item.quantity;
          await product.save();
        }
      }
    }

    // Create notification for buyer
    const notificationType = status === 'approved' ? 'return_approved' : status === 'rejected' ? 'return_rejected' : 'return_completed';
    await createNotification(
      returnRequest.userId,
      `Your ${returnRequest.type} request for order #${returnRequest.orderId.toString().slice(-8)} has been ${status}.`,
      '/orders',
      notificationType
    );

    const updatedReturn = await Return.findById(returnRequest._id)
      .populate('orderId')
      .populate('items.productId', 'title images')
      .populate('userId', 'name email');

    res.json(updatedReturn);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

