import jwt from 'jsonwebtoken';
import User from '../models/User.js';

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || '7d',
  });
};

// @desc    Register user
// @route   POST /api/auth/register
// @access  Public
export const register = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password || !role) {
      return res.status(400).json({ message: 'Please provide all fields including role' });
    }

    // Validate role
    if (!['buyer', 'seller', 'admin'].includes(role)) {
      return res.status(400).json({ message: 'Invalid role. Must be buyer, seller, or admin' });
    }

    // Check if user exists
    const userExists = await User.findOne({ email });
    
    if (userExists) {
      // If deleted, allow re-registration (remove old record)
      if (userExists.isDeleted) {
        await User.findByIdAndDelete(userExists._id);
      } 
      // If rejected seller, don't allow re-registration with same email
      else if (userExists.approvalStatus === 'rejected' && userExists.role === 'seller') {
        return res.status(400).json({ message: 'This email was used by a rejected seller account and cannot be used again.' });
      }
      // If not deleted and not rejected, user already exists
      else {
        return res.status(400).json({ message: 'User already exists' });
      }
    }

    // Set approval status based on role
    let approvalStatus = 'approved';
    if (role === 'seller') {
      approvalStatus = 'pending'; // Sellers need admin approval
    }

    const user = await User.create({
      name,
      email,
      passwordHash: password,
      role: role,
      approvalStatus: approvalStatus,
    });

    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: generateToken(user._id),
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Login user
// @route   POST /api/auth/login
// @access  Public
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Please provide email and password' });
    }

    const user = await User.findOne({ email });

    if (!user || !(await user.matchPassword(password))) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    // Check if user is deleted
    if (user.isDeleted) {
      return res.status(401).json({ message: 'Account has been deleted. Please register again.' });
    }
    
    // Check if seller is rejected
    if (user.role === 'seller' && user.approvalStatus === 'rejected') {
      return res.status(401).json({ message: 'Your seller account has been rejected. You cannot login with this email.' });
    }

    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: generateToken(user._id),
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get current user
// @route   GET /api/auth/me
// @access  Private
export const getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('-passwordHash');
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update user profile
// @route   PUT /api/auth/profile
// @access  Private
export const updateProfile = async (req, res) => {
  try {
    const { name, phone, address, sellerProfile } = req.body;
    const user = await User.findById(req.user._id);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (name) user.name = name;
    if (phone !== undefined) {
      if (!user.profile) user.profile = {};
      user.profile.phone = phone;
    }
    if (address !== undefined && address !== null) {
      if (!user.profile) user.profile = {};
      user.profile.address = {
        street: address.street || user.profile?.address?.street || '',
        city: address.city || user.profile?.address?.city || '',
        state: address.state || user.profile?.address?.state || '',
        zipCode: address.zipCode || user.profile?.address?.zipCode || '',
        country: address.country || user.profile?.address?.country || '',
      };
    }
    if (sellerProfile && user.role === 'seller') {
      if (!user.sellerProfile) user.sellerProfile = {};
      user.sellerProfile.storeName = sellerProfile.storeName || user.sellerProfile.storeName;
      user.sellerProfile.description = sellerProfile.description || user.sellerProfile.description;
      user.sellerProfile.phone = sellerProfile.phone || user.sellerProfile.phone;
      user.sellerProfile.gstNumber = sellerProfile.gstNumber || user.sellerProfile.gstNumber;
      if (sellerProfile.address) {
        if (!user.sellerProfile.address) user.sellerProfile.address = {};
        user.sellerProfile.address.street = sellerProfile.address.street || user.sellerProfile.address?.street || '';
        user.sellerProfile.address.city = sellerProfile.address.city || user.sellerProfile.address?.city || '';
        user.sellerProfile.address.state = sellerProfile.address.state || user.sellerProfile.address?.state || '';
        user.sellerProfile.address.zipCode = sellerProfile.address.zipCode || user.sellerProfile.address?.zipCode || '';
        user.sellerProfile.address.country = sellerProfile.address.country || user.sellerProfile.address?.country || '';
      }
    }

    await user.save();

    const updatedUser = await User.findById(user._id).select('-passwordHash');
    res.json(updatedUser);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Forgot password - send OTP
// @route   POST /api/auth/forgot-password
// @access  Public
export const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: 'Please provide email address' });
    }

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: 'User not found with this email' });
    }

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const otpExpiry = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    user.resetPasswordOTP = otp;
    user.resetPasswordOTPExpiry = otpExpiry;
    await user.save();

    // Send OTP email
    const { sendOTPEmail } = await import('../utils/emailService.js');
    await sendOTPEmail(user.email, otp);

    res.json({ message: 'OTP sent to your email address' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Verify OTP and reset password
// @route   POST /api/auth/reset-password
// @access  Public
export const resetPassword = async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;

    if (!email || !otp || !newPassword) {
      return res.status(400).json({ message: 'Please provide email, OTP, and new password' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters long' });
    }

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (user.resetPasswordOTP !== otp) {
      return res.status(400).json({ message: 'Invalid OTP' });
    }

    if (!user.resetPasswordOTPExpiry || new Date() > user.resetPasswordOTPExpiry) {
      return res.status(400).json({ message: 'OTP has expired. Please request a new one.' });
    }

    // Update password (will be hashed by pre-save hook)
    user.passwordHash = newPassword;
    user.resetPasswordOTP = undefined;
    user.resetPasswordOTPExpiry = undefined;
    await user.save();

    // Send confirmation email
    const { sendPasswordChangedEmail } = await import('../utils/emailService.js');
    await sendPasswordChangedEmail(user.email, user.name);

    res.json({ message: 'Password reset successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

