import mongoose from 'mongoose';

const reviewSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true,
  },
  rating: {
    type: Number,
    required: true,
    min: 1,
    max: 5,
  },
  comment: {
    type: String,
    trim: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

// One review per user per product
reviewSchema.index({ userId: 1, productId: 1 }, { unique: true });

// Update updatedAt on save
reviewSchema.pre('save', function (next) {
  if (this.isModified('rating') || this.isModified('comment')) {
    this.updatedAt = new Date();
  }
  next();
});

const Review = mongoose.model('Review', reviewSchema);

export default Review;

