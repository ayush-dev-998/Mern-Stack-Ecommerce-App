import express from 'express';
import { getProducts, getProduct, addReview } from '../controllers/productController.js';
import { protect, requireRole } from '../middleware/auth.js';

const router = express.Router();

router.get('/', getProducts);
router.get('/:id', getProduct);
router.post('/:id/review', protect, requireRole('buyer'), addReview);

export default router;

