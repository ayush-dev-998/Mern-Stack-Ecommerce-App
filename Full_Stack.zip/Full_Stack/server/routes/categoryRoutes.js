import express from 'express';
import Category from '../models/Category.js';

const router = express.Router();

// @desc    Get all categories (public)
// @route   GET /api/categories
router.get('/', async (req, res) => {
  try {
    const categories = await Category.find().sort({ name: 1 });
    res.json(categories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;

