import express from 'express';
import { requestReturn, getBuyerReturns } from '../controllers/returnController.js';
import { protect, requireRole } from '../middleware/auth.js';

const router = express.Router();

router.use(protect, requireRole('buyer'));

router.post('/', requestReturn);
router.get('/', getBuyerReturns);

export default router;

