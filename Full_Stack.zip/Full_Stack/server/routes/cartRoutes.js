import express from 'express';
import { getCart, updateCart, removeFromCart, emptyCart } from '../controllers/cartController.js';
import { protect, requireRole } from '../middleware/auth.js';

const router = express.Router();

router.use(protect, requireRole('buyer'));

router.get('/', getCart);
router.post('/', updateCart);
router.delete('/:productId', removeFromCart);
router.delete('/', emptyCart);

export default router;

