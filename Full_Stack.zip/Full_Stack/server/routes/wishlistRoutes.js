import express from 'express';
import {
  getWishlist,
  addToWishlist,
  removeFromWishlist,
  emptyWishlist,
} from '../controllers/wishlistController.js';
import { protect, requireRole } from '../middleware/auth.js';

const router = express.Router();

router.use(protect, requireRole('buyer'));

router.get('/', getWishlist);
router.post('/', addToWishlist);
router.delete('/:productId', removeFromWishlist);
router.delete('/', emptyWishlist);

export default router;

