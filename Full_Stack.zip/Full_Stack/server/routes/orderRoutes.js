import express from 'express';
import { checkout, getOrders, cancelOrder } from '../controllers/orderController.js';
import { protect, requireRole } from '../middleware/auth.js';

const router = express.Router();

router.post('/checkout', protect, requireRole('buyer'), checkout);
router.get('/orders', protect, requireRole('buyer'), getOrders);
router.patch('/orders/:id/cancel', protect, requireRole('buyer'), cancelOrder);

export default router;

