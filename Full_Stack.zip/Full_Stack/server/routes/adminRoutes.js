import express from 'express';
import {
  getUsers,
  updateUserRole,
  deleteUser,
  approveSeller,
  rejectSeller,
  getStats,
  getCategories,
  createCategory,
  getAdminProducts,
  createAdminProduct,
  updateAdminProduct,
  deleteAdminProduct,
  getAdminOrders,
} from '../controllers/adminController.js';
import { protect, requireRole } from '../middleware/auth.js';

const router = express.Router();

router.use(protect, requireRole('admin'));

// Stats
router.get('/stats', getStats);

// Users
router.get('/users', getUsers);
router.patch('/users/:id/role', updateUserRole);
router.delete('/users/:id', deleteUser);

// Sellers
router.patch('/sellers/:id/approve', approveSeller);
router.patch('/sellers/:id/reject', rejectSeller);

// Categories
router.get('/categories', getCategories);
router.post('/categories', createCategory);

// Products
router.get('/products', getAdminProducts);
router.post('/products', createAdminProduct);
router.put('/products/:id', updateAdminProduct);
router.delete('/products/:id', deleteAdminProduct);

// Orders
router.get('/orders', getAdminOrders);

export default router;

